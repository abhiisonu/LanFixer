using System.Diagnostics;
using System.Net;
using System.Text;
using System.Text.Json;

namespace LanFixer;

public static class WebServer
{
    private static HttpListener? _listener;
    private static CancellationTokenSource? _cts;
    private static readonly List<int> _history = new();
    private static readonly object _histLock = new();
    public static int Port = 49888;
    public static bool Running => _listener is { IsListening: true };

    public static void Start(int port = 49888, bool openBrowser = true)
    {
        if (Running)
        {
            if (openBrowser) OpenBrowser($"http://127.0.0.1:{Port}/");
            return;
        }

        Port = port;
        _cts = new CancellationTokenSource();

        for (int retry = 0; retry < 5; retry++)
        {
            try
            {
                _listener = new HttpListener();
                _listener.Prefixes.Add($"http://127.0.0.1:{Port}/");
                _listener.Start();
                break;
            }
            catch
            {
                Port++;
                _listener = null;
            }
        }

        if (_listener == null || !_listener.IsListening)
        {
            Console.Error.WriteLine("[!] Could not bind local HTTP server.");
            return;
        }

        Task.Run(() => ListenLoop(_listener, _cts.Token));

        var url = $"http://127.0.0.1:{Port}/";
        Console.WriteLine($"\n  ============================================================================");
        Console.WriteLine($"    LANFIXER SUPREME MODERN INDUSTRIAL WEB DASHBOARD ACTIVE");
        Console.WriteLine($"    URL : {url}");
        Console.WriteLine($"  ============================================================================\n");

        if (openBrowser)
        {
            OpenBrowser(url);
        }
    }

    public static void Stop()
    {
        try
        {
            _cts?.Cancel();
            _listener?.Stop();
            _listener?.Close();
        }
        catch { }
    }

    private static void OpenBrowser(string url)
    {
        try
        {
            Process.Start(new ProcessStartInfo(url) { UseShellExecute = true });
        }
        catch { }
    }

    private static async Task ListenLoop(HttpListener listener, CancellationToken ct)
    {
        while (!ct.IsCancellationRequested && listener.IsListening)
        {
            try
            {
                var ctx = await listener.GetContextAsync();
                _ = Task.Run(() => HandleRequest(ctx), ct);
            }
            catch (HttpListenerException) { break; }
            catch (ObjectDisposedException) { break; }
            catch { }
        }
    }

    private static async Task HandleRequest(HttpListenerContext ctx)
    {
        var req = ctx.Request;
        var resp = ctx.Response;

        resp.Headers.Add("Access-Control-Allow-Origin", "*");
        resp.Headers.Add("Access-Control-Allow-Methods", "GET, POST, OPTIONS");
        resp.Headers.Add("Access-Control-Allow-Headers", "Content-Type");

        if (req.HttpMethod == "OPTIONS")
        {
            resp.StatusCode = 204;
            resp.Close();
            return;
        }

        var path = req.Url?.AbsolutePath.ToLowerInvariant() ?? "/";

        try
        {
            if (path is "/" or "/index.html")
            {
                string html = WebUi.GetHtml();
                var candidates = new[]
                {
                    Path.Combine(AppContext.BaseDirectory, "lanfixer_ui ux.html"),
                    Path.Combine(AppContext.BaseDirectory, "ui.html"),
                    Path.Combine(Directory.GetCurrentDirectory(), "lanfixer_ui ux.html"),
                    @"C:\Users\ABHISHEK SONU\Desktop\Lan Fixer\lanfixer_ui ux.html"
                };
                foreach (var c in candidates)
                {
                    if (File.Exists(c))
                    {
                        try { html = File.ReadAllText(c); break; }
                        catch { }
                    }
                }
                var buf = Encoding.UTF8.GetBytes(html);
                resp.ContentType = "text/html; charset=utf-8";
                resp.ContentLength64 = buf.Length;
                await resp.OutputStream.WriteAsync(buf);
            }
            else if (path == "/api/status")
            {
                var s = Fmt.Parse(Ipc.AskSync("status", 1000));
                if (s == null)
                {
                    var l = Net.Primary();
                    var (st, _, ms) = await Net.Probe(l?.Ip, default);
                    int gwMs = -1;
                    if (!string.IsNullOrEmpty(l?.Gw))
                    {
                        gwMs = await Net.Rtt(l.Gw, 1000);
                    }
                    var dnsServers = (l != null ? Dns.Current(l.Id).ToList() : new List<string>());
                    if (dnsServers.Count == 0) dnsServers.AddRange(new[] { "1.1.1.1", "8.8.8.8" });
                    int netMs = -1;
                    foreach (var srv in dnsServers)
                    {
                        netMs = await Dns.Ms(srv, default);
                        if (netMs >= 0) break;
                    }

                    lock (_histLock)
                    {
                        _history.Add(ms >= 0 ? ms : (gwMs >= 0 ? gwMs : 0));
                        if (_history.Count > 50) _history.RemoveAt(0);
                    }

                    List<string> logs;
                    lock (Log.Ring) { logs = Log.Ring.TakeLast(25).ToList(); }

                    s = new Status
                    {
                        State = l == null ? "NoLink" : st.ToString(),
                        Ms = ms,
                        GwMs = gwMs,
                        NetMs = netMs,
                        Loss = (ms < 0 && gwMs >= 0) ? 50 : (ms < 0 ? 100 : 0),
                        Heals = 0,
                        Adapter = l?.Name ?? "None",
                        Ip = l?.Ip ?? "",
                        Gw = l?.Gw ?? "",
                        Vault = Vault.Exists,
                        Susp = File.Exists(P.Susp),
                        Hist = new List<int>(_history),
                        Events = logs
                    };
                }
                var json = JsonSerializer.Serialize(s, J.Default.Status);
                var buf = Encoding.UTF8.GetBytes(json);
                resp.ContentType = "application/json; charset=utf-8";
                resp.ContentLength64 = buf.Length;
                await resp.OutputStream.WriteAsync(buf);
            }
            else if (path == "/api/doctor")
            {
                var doc = Doctor.Run();
                var json = JsonSerializer.Serialize(doc, J.Default.DoctorReport);
                var buf = Encoding.UTF8.GetBytes(json);
                resp.ContentType = "application/json; charset=utf-8";
                resp.ContentLength64 = buf.Length;
                await resp.OutputStream.WriteAsync(buf);
            }
            else if (path == "/api/bench")
            {
                var primary = Net.Primary();
                var res = await Bench.RunAsync(primary?.Gw);
                var json = JsonSerializer.Serialize(res, J.Default.ListBenchTarget);
                var buf = Encoding.UTF8.GetBytes(json);
                resp.ContentType = "application/json; charset=utf-8";
                resp.ContentLength64 = buf.Length;
                await resp.OutputStream.WriteAsync(buf);
            }
            else if (path == "/api/bundle")
            {
                Engine.Init();
                var msg = await Engine.CreateBundleAsync();
                var lines = msg.Split('\n');
                var filePath = lines.Length > 1 ? lines[1].Trim().Split(' ')[0] : null;
                byte[] buf;
                if (filePath != null && File.Exists(filePath))
                {
                    buf = await File.ReadAllBytesAsync(filePath);
                }
                else
                {
                    buf = Encoding.UTF8.GetBytes("{\"error\": \"Could not generate bundle\"}");
                }
                resp.ContentType = "application/json; charset=utf-8";
                resp.Headers.Add("Content-Disposition", $"attachment; filename=\"LanFixer-Bundle-{DateTime.Now:yyyyMMdd-HHmmss}.json\"");
                resp.ContentLength64 = buf.Length;
                await resp.OutputStream.WriteAsync(buf);
            }
            else if (path == "/api/cred")
            {
                if (req.HttpMethod == "GET")
                {
                    var cred = Vault.Load();
                    var dto = new CredInfoDto
                    {
                        Exists = Vault.Exists,
                        User = cred?.U ?? "",
                        Host = cred?.H ?? "",
                        Port = cred?.Port ?? 8888
                    };
                    var json = JsonSerializer.Serialize(dto, J.Default.CredInfoDto);
                    var buf = Encoding.UTF8.GetBytes(json);
                    resp.ContentType = "application/json; charset=utf-8";
                    resp.ContentLength64 = buf.Length;
                    await resp.OutputStream.WriteAsync(buf);
                }
                else if (req.HttpMethod == "POST")
                {
                    using var reader = new StreamReader(req.InputStream, req.ContentEncoding);
                    var body = await reader.ReadToEndAsync();
                    string u = "", p = "", h = "";
                    int port = 8888;
                    try
                    {
                        using var doc = JsonDocument.Parse(body);
                        if (doc.RootElement.TryGetProperty("u", out var up)) u = up.GetString() ?? "";
                        if (doc.RootElement.TryGetProperty("p", out var pp)) p = pp.GetString() ?? "";
                        if (doc.RootElement.TryGetProperty("h", out var hp)) h = hp.GetString() ?? "";
                        if (doc.RootElement.TryGetProperty("port", out var ptp)) port = ptp.GetInt32();
                    }
                    catch { }

                    bool ok = false;
                    string msg = "";
                    if (string.IsNullOrWhiteSpace(u) || string.IsNullOrWhiteSpace(p))
                    {
                        msg = "Username and password cannot be empty.";
                    }
                    else
                    {
                        var cred = new Cred { U = u, P = p, H = h, Port = port > 0 ? port : 8888 };
                        ok = Vault.Save(cred);
                        msg = ok ? $"Credentials successfully encrypted & stored in machine DPAPI vault (Target: {h}:{port})." : "Failed to encrypt credentials with DPAPI.";
                    }
                    var dto = new ActionResultDto { Ok = ok, Result = msg };
                    var json = JsonSerializer.Serialize(dto, J.Default.ActionResultDto);
                    var buf = Encoding.UTF8.GetBytes(json);
                    resp.ContentType = "application/json; charset=utf-8";
                    resp.ContentLength64 = buf.Length;
                    await resp.OutputStream.WriteAsync(buf);
                }
            }
            else if (path == "/api/logs")
            {
                List<string> logs;
                lock (Log.Ring) { logs = Log.Ring.TakeLast(50).ToList(); }
                var json = JsonSerializer.Serialize(logs, J.Default.ListString);
                var buf = Encoding.UTF8.GetBytes(json);
                resp.ContentType = "application/json; charset=utf-8";
                resp.ContentLength64 = buf.Length;
                await resp.OutputStream.WriteAsync(buf);
            }
            else if (path == "/api/action" && req.HttpMethod == "POST")
            {
                using var reader = new StreamReader(req.InputStream, req.ContentEncoding);
                var body = await reader.ReadToEndAsync();
                string cmd = "repair";
                try
                {
                    using var doc = JsonDocument.Parse(body);
                    if (doc.RootElement.TryGetProperty("cmd", out var cp)) cmd = cp.GetString() ?? "repair";
                }
                catch { }

                string? result = Ipc.AskSync(cmd);
                if (result == null)
                {
                    bool reqAdmin = cmd switch
                    {
                        "bench" or "bundle" or "audit" or "keepalive" or "doctor" => false,
                        _ => true
                    };
                    if (reqAdmin && !P.Admin())
                    {
                        result = "Elevated administrator privileges or background service required for this operation.";
                    }
                    else
                    {
                        Engine.Init();
                        result = await Engine.Do(cmd);
                    }
                }
                var dto = new ActionResultDto
                {
                    Ok = !result.StartsWith("Error") && !result.StartsWith("Refused") && !result.StartsWith("Aborted"),
                    Result = result
                };
                var json = JsonSerializer.Serialize(dto, J.Default.ActionResultDto);
                var buf = Encoding.UTF8.GetBytes(json);
                resp.ContentType = "application/json; charset=utf-8";
                resp.ContentLength64 = buf.Length;
                await resp.OutputStream.WriteAsync(buf);
            }
            else
            {
                resp.StatusCode = 404;
                var buf = Encoding.UTF8.GetBytes("Not Found");
                await resp.OutputStream.WriteAsync(buf);
            }
        }
        catch (Exception ex)
        {
            try
            {
                resp.StatusCode = 500;
                var buf = Encoding.UTF8.GetBytes("Error: " + ex.Message);
                await resp.OutputStream.WriteAsync(buf);
            }
            catch { }
        }
        finally
        {
            try { resp.Close(); } catch { }
        }
    }
}

public static class WebUi
{
    public static string GetHtml() =>
"""
<!DOCTYPE html>
<html lang="en" data-mode="light">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>LanFixer — Network Studio</title>
  <link rel="preconnect" href="https://fonts.googleapis.com" />
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=JetBrains+Mono:wght@400;500;600&family=Plus+Jakarta+Sans:wght@600;700;800&display=swap" rel="stylesheet" />
  <script src="https://cdn.tailwindcss.com"></script>
  <script>
    tailwind.config = {
      theme: {
        extend: {
          fontFamily: {
            display: ['Plus Jakarta Sans', '-apple-system', 'BlinkMacSystemFont', 'sans-serif'],
            sans: ['Inter', '-apple-system', 'BlinkMacSystemFont', 'SF Pro Text', 'sans-serif'],
            mono: ['JetBrains Mono', 'SF Mono', 'monospace'],
          },
        },
      },
    };
  </script>
  <style>
    /* =========================================================================
       MACOS SEQUOIA / LIQUID GLASS DESIGN TOKENS
       Precision specular edges, multi-layered atmospheric depth, zero clutter
       ========================================================================= */
    :root[data-mode="light"] {
      --bg-base: #ECEEEB;
      --window-bg: rgba(250, 251, 250, 0.78);
      --sidebar-bg: rgba(242, 243, 240, 0.68);
      --card-bg: rgba(255, 255, 255, 0.86);
      --card-solid: #FFFFFF;
      --card-inset: rgba(242, 243, 245, 0.78);
      --card-hover: rgba(255, 255, 255, 0.96);
      --hairline: rgba(15, 23, 42, 0.075);
      --hairline-strong: rgba(15, 23, 42, 0.14);
      --specular: rgba(255, 255, 255, 0.92);
      --ink-1: #0F1115;
      --ink-2: #4B505A;
      --ink-3: #868B96;
      --primary-bg: #111318;
      --primary-ink: #FFFFFF;
      --nav-active-bg: rgba(15, 17, 21, 0.075);
      --nav-active-ink: #0F1115;
      --shadow-window: 0 30px 90px -24px rgba(15, 23, 42, 0.18), 0 0 0 1px rgba(15, 23, 42, 0.07);
      --shadow-card: 0 1px 0 0 rgba(255, 255, 255, 0.95) inset, 0 2px 6px -1px rgba(15, 23, 42, 0.04), 0 12px 28px -12px rgba(15, 23, 42, 0.075);
      --shadow-float: 0 18px 44px -10px rgba(15, 23, 42, 0.16), 0 0 0 1px rgba(15, 23, 42, 0.08);
      --ok: #0E9F6E;
      --ok-soft: rgba(14, 159, 110, 0.11);
      --warn: #D97706;
      --warn-soft: rgba(217, 119, 6, 0.12);
      --bad: #E02424;
      --bad-soft: rgba(224, 36, 36, 0.11);
      --blue: #2563EB;
      --blue-soft: rgba(37, 99, 235, 0.11);
      --track: rgba(15, 23, 42, 0.10);
      --spot-glow: rgba(255, 255, 255, 0.65);
    }

    :root[data-mode="dark"] {
      --bg-base: #07080B;
      --window-bg: rgba(19, 21, 26, 0.78);
      --sidebar-bg: rgba(14, 16, 20, 0.72);
      --card-bg: rgba(28, 31, 38, 0.72);
      --card-solid: #1B1E25;
      --card-inset: rgba(15, 17, 22, 0.62);
      --card-hover: rgba(36, 40, 49, 0.86);
      --hairline: rgba(255, 255, 255, 0.075);
      --hairline-strong: rgba(255, 255, 255, 0.15);
      --specular: rgba(255, 255, 255, 0.14);
      --ink-1: #F5F6FA;
      --ink-2: #A2A8B4;
      --ink-3: #6B7280;
      --primary-bg: #F5F6FA;
      --primary-ink: #0B0D11;
      --nav-active-bg: rgba(255, 255, 255, 0.10);
      --nav-active-ink: #FFFFFF;
      --shadow-window: 0 36px 100px -20px rgba(0, 0, 0, 0.85), 0 0 0 1px rgba(255, 255, 255, 0.09);
      --shadow-card: 0 1px 0 0 rgba(255, 255, 255, 0.09) inset, 0 14px 36px -14px rgba(0, 0, 0, 0.65);
      --shadow-float: 0 24px 56px -12px rgba(0, 0, 0, 0.82), 0 0 0 1px rgba(255, 255, 255, 0.11);
      --ok: #34D399;
      --ok-soft: rgba(52, 211, 153, 0.14);
      --warn: #FBBF24;
      --warn-soft: rgba(251, 191, 36, 0.14);
      --bad: #F87171;
      --bad-soft: rgba(248, 113, 113, 0.14);
      --blue: #60A5FA;
      --blue-soft: rgba(96, 165, 250, 0.14);
      --track: rgba(255, 255, 255, 0.13);
      --spot-glow: rgba(255, 255, 255, 0.06);
    }

    * { box-sizing: border-box; -webkit-font-smoothing: antialiased; -moz-osx-font-smoothing: grayscale; }

    html, body {
      margin: 0;
      padding: 0;
      background: var(--bg-base);
      color: var(--ink-1);
      font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;
      transition: background-color 340ms cubic-bezier(0.22, 1, 0.36, 1), color 240ms ease;
      overflow-x: hidden;
      min-height: 100vh;
    }

    .tabular { font-variant-numeric: tabular-nums; }

    /* Main Translucent macOS Desktop Window Frame */
    .mac-window {
      background: var(--window-bg);
      backdrop-filter: blur(42px) saturate(165%);
      -webkit-backdrop-filter: blur(42px) saturate(165%);
      box-shadow: var(--shadow-window);
      transition: background-color 320ms ease, box-shadow 320ms ease;
    }

    .mac-sidebar {
      background: var(--sidebar-bg);
      border-right: 1px solid var(--hairline);
      transition: background-color 320ms ease, border-color 240ms ease;
    }

    /* Liquid Glass Card with Pointer-Tracking Specular Highlight */
    .mac-card {
      position: relative;
      background: var(--card-bg);
      backdrop-filter: blur(24px) saturate(145%);
      -webkit-backdrop-filter: blur(24px) saturate(145%);
      border: 1px solid var(--hairline);
      box-shadow: var(--shadow-card);
      transition: transform 240ms cubic-bezier(0.22, 1, 0.36, 1), border-color 220ms ease, background-color 260ms ease, box-shadow 240ms ease;
      overflow: hidden;
    }
    .mac-card::before {
      content: '';
      position: absolute;
      inset: 0;
      pointer-events: none;
      opacity: 0;
      background: radial-gradient(360px circle at var(--mx, 50%) var(--my, 50%), var(--spot-glow), transparent 65%);
      transition: opacity 280ms ease;
    }
    .mac-card:hover::before { opacity: 1; }
    .mac-card-lift:hover {
      border-color: var(--hairline-strong);
      transform: translateY(-1.5px);
    }

    .mac-inset {
      background: var(--card-inset);
      border: 1px solid var(--hairline);
    }

    .mac-float {
      background: var(--card-bg);
      backdrop-filter: blur(34px) saturate(170%);
      -webkit-backdrop-filter: blur(34px) saturate(170%);
      box-shadow: var(--shadow-float);
    }

    /* Buttons */
    .btn-primary {
      background: var(--primary-bg);
      color: var(--primary-ink);
      box-shadow: 0 6px 18px -6px rgba(0, 0, 0, 0.28);
      transition: transform 160ms cubic-bezier(0.22, 1, 0.36, 1), opacity 160ms ease, box-shadow 200ms ease;
      cursor: pointer;
    }
    .btn-primary:hover { opacity: 0.91; transform: translateY(-1px); }
    .btn-primary:active { transform: scale(0.97); }

    .btn-glass {
      background: var(--card-bg);
      color: var(--ink-1);
      border: 1px solid var(--hairline);
      box-shadow: 0 1px 0 var(--specular) inset, 0 1px 3px rgba(0,0,0,0.03);
      transition: background-color 160ms ease, border-color 160ms ease, transform 140ms ease;
      cursor: pointer;
    }
    .btn-glass:hover { background: var(--card-hover); border-color: var(--hairline-strong); }
    .btn-glass:active { transform: scale(0.97); }

    /* Sidebar Navigation Row */
    .nav-row {
      color: var(--ink-2);
      transition: background-color 160ms ease, color 160ms ease, transform 140ms ease;
      cursor: pointer;
    }
    .nav-row:hover { background: var(--nav-active-bg); color: var(--ink-1); }
    .nav-row[data-active="true"] {
      background: var(--nav-active-bg);
      color: var(--nav-active-ink);
      font-weight: 600;
      box-shadow: 0 1px 0 var(--specular) inset;
    }

    /* Mobile Dock Pill */
    .dock-btn {
      color: var(--ink-2);
      transition: background-color 180ms ease, color 180ms ease;
      cursor: pointer;
    }
    .dock-btn[data-active="true"] {
      background: var(--primary-bg);
      color: var(--primary-ink);
    }

    /* Native macOS Toggle Switch */
    .mac-switch {
      width: 42px;
      height: 24px;
      border-radius: 9999px;
      background: var(--track);
      position: relative;
      transition: background-color 240ms cubic-bezier(0.22, 1, 0.36, 1);
      cursor: pointer;
      flex-shrink: 0;
      border: none;
    }
    .mac-switch[data-on="true"] { background: var(--ok); }
    .mac-switch::after {
      content: '';
      position: absolute;
      top: 2px; left: 2px;
      width: 20px; height: 20px;
      border-radius: 9999px;
      background: #FFFFFF;
      box-shadow: 0 2px 5px rgba(0, 0, 0, 0.22);
      transition: transform 250ms cubic-bezier(0.34, 1.56, 0.64, 1);
    }
    .mac-switch[data-on="true"]::after { transform: translateX(18px); }

    /* Segmented Control (Apple HIG) */
    .seg-wrap {
      background: var(--card-inset);
      border: 1px solid var(--hairline);
      padding: 3px;
      border-radius: 9999px;
      display: inline-flex;
      gap: 2px;
    }
    .seg-item {
      padding: 5px 12px;
      border-radius: 9999px;
      font-size: 12px;
      font-weight: 500;
      color: var(--ink-2);
      transition: background-color 180ms ease, color 180ms ease, box-shadow 180ms ease;
      cursor: pointer;
      white-space: nowrap;
    }
    .seg-item[data-active="true"] {
      background: var(--card-solid);
      color: var(--ink-1);
      font-weight: 600;
      box-shadow: 0 2px 8px -2px rgba(0, 0, 0, 0.14);
    }

    /* Smooth View Reveal */
    @keyframes macFadeIn {
      from { opacity: 0; transform: translateY(8px) scale(0.994); }
      to   { opacity: 1; transform: translateY(0) scale(1); }
    }
    .view-animate { animation: macFadeIn 300ms cubic-bezier(0.22, 1, 0.36, 1) forwards; }

    @keyframes modalPop {
      from { opacity: 0; transform: scale(0.95) translateY(6px); }
      to   { opacity: 1; transform: scale(1) translateY(0); }
    }
    .modal-pop { animation: modalPop 220ms cubic-bezier(0.22, 1, 0.36, 1) forwards; }

    /* 3D Credential Pass Sheen */
    .vault-pass {
      background: linear-gradient(135deg, #161922 0%, #232A38 52%, #11151E 100%);
      color: #F8FAFC;
      box-shadow: 0 20px 44px -16px rgba(15, 23, 42, 0.45), 0 1px 0 rgba(255,255,255,0.22) inset;
      transition: transform 280ms cubic-bezier(0.22, 1, 0.36, 1);
    }

    /* Semantic Color Helpers */
    .c-1 { color: var(--ink-1); }
    .c-2 { color: var(--ink-2); }
    .c-3 { color: var(--ink-3); }
    .c-ok { color: var(--ok); }
    .c-warn { color: var(--warn); }
    .c-bad { color: var(--bad); }
    .c-blue { color: var(--blue); }
    .b-hair { border-color: var(--hairline); }

    
    /* =========================================================================
       OFFLINE-FIRST DESIGN ENGINE & RESILIENT FALLBACK UTILITIES
       Ensures 100% layout fidelity when disconnected from Tailwind CDN
       ========================================================================= */
    .flex { display: flex; }
    .hidden { display: none !important; }
    .inline-block { display: inline-block; }
    .inline-flex { display: inline-flex; }
    .block { display: block; }
    .grid { display: grid; }
    .flex-col { flex-direction: column; }
    .flex-row { flex-direction: row; }
    .flex-wrap { flex-wrap: wrap; }
    .flex-1 { flex: 1 1 0%; }
    .shrink-0 { flex-shrink: 0; }
    .items-center { align-items: center; }
    .items-start { align-items: flex-start; }
    .items-end { align-items: flex-end; }
    .items-stretch { align-items: stretch; }
    .items-baseline { align-items: baseline; }
    .justify-between { justify-content: space-between; }
    .justify-center { justify-content: center; }
    .justify-end { justify-content: flex-end; }
    .w-full { width: 100%; }
    .h-full { height: 100%; }
    .min-w-0 { min-width: 0; }
    .min-h-screen { min-height: 100vh; }
    .relative { position: relative; }
    .absolute { position: absolute; }
    .fixed { position: fixed; }
    .inset-0 { top: 0; right: 0; bottom: 0; left: 0; }
    .z-0 { z-index: 0; }
    .z-10 { z-index: 10; }
    .z-30 { z-index: 30; }
    .z-40 { z-index: 40; }
    .z-50 { z-index: 50; }
    .overflow-hidden { overflow: hidden; }
    .overflow-y-auto { overflow-y: auto; }
    .overflow-x-auto { overflow-x: auto; }
    .truncate { overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
    .whitespace-nowrap { white-space: nowrap; }
    .break-all { word-break: break-all; }
    .rounded-full { border-radius: 9999px; }
    .rounded-2xl { border-radius: 1rem; }
    .rounded-xl { border-radius: 0.75rem; }
    .rounded-lg { border-radius: 0.5rem; }
    .rounded-md { border-radius: 0.375rem; }
    .rounded-\[14px\] { border-radius: 14px; }
    .rounded-\[24px\] { border-radius: 24px; }
    .rounded-\[26px\] { border-radius: 26px; }
    .rounded-\[28px\] { border-radius: 28px; }
    .rounded-\[30px\] { border-radius: 30px; }
    .border { border-width: 1px; }
    .border-b { border-bottom-width: 1px; }
    .border-t { border-top-width: 1px; }
    .border-l { border-left-width: 1px; }
    .border-r { border-right-width: 1px; }
    .text-xs { font-size: 0.75rem; line-height: 1rem; }
    .text-sm { font-size: 0.875rem; line-height: 1.25rem; }
    .text-base { font-size: 1rem; line-height: 1.5rem; }
    .text-lg { font-size: 1.125rem; line-height: 1.75rem; }
    .text-2xl { font-size: 1.5rem; line-height: 2rem; }
    .text-3xl { font-size: 1.875rem; line-height: 2.25rem; }
    .text-4xl { font-size: 2.25rem; line-height: 2.5rem; }
    .text-\[10px\] { font-size: 10px; }
    .text-\[11px\] { font-size: 11px; }
    .text-\[13px\] { font-size: 13px; }
    .text-\[13\.5px\] { font-size: 13.5px; }
    .text-\[15px\] { font-size: 15px; }
    .text-center { text-align: center; }
    .text-left { text-align: left; }
    .text-right { text-align: right; }
    .font-semibold { font-weight: 600; }
    .font-bold { font-weight: 700; }
    .font-medium { font-weight: 500; }
    .font-mono { font-family: 'JetBrains Mono', 'SF Mono', monospace; }
    .font-display { font-family: 'Plus Jakarta Sans', -apple-system, sans-serif; }
    .gap-1 { gap: 0.25rem; }
    .gap-1\.5 { gap: 0.375rem; }
    .gap-2 { gap: 0.5rem; }
    .gap-2\.5 { gap: 0.625rem; }
    .gap-3 { gap: 0.75rem; }
    .gap-3\.5 { gap: 0.875rem; }
    .gap-4 { gap: 1rem; }
    .gap-5 { gap: 1.25rem; }
    .gap-6 { gap: 1.5rem; }
    .gap-7 { gap: 1.75rem; }
    .space-y-1 > :not([hidden]) ~ :not([hidden]) { margin-top: 0.25rem; }
    .space-y-1\.5 > :not([hidden]) ~ :not([hidden]) { margin-top: 0.375rem; }
    .space-y-2 > :not([hidden]) ~ :not([hidden]) { margin-top: 0.5rem; }
    .space-y-2\.5 > :not([hidden]) ~ :not([hidden]) { margin-top: 0.625rem; }
    .space-y-3 > :not([hidden]) ~ :not([hidden]) { margin-top: 0.75rem; }
    .space-y-3\.5 > :not([hidden]) ~ :not([hidden]) { margin-top: 0.875rem; }
    .space-y-4 > :not([hidden]) ~ :not([hidden]) { margin-top: 1rem; }
    .space-y-5 > :not([hidden]) ~ :not([hidden]) { margin-top: 1.25rem; }
    .space-y-6 > :not([hidden]) ~ :not([hidden]) { margin-top: 1.5rem; }
    .p-1 { padding: 0.25rem; }
    .p-1\.5 { padding: 0.375rem; }
    .p-2 { padding: 0.5rem; }
    .p-2\.5 { padding: 0.625rem; }
    .p-3 { padding: 0.75rem; }
    .p-3\.5 { padding: 0.875rem; }
    .p-4 { padding: 1rem; }
    .p-5 { padding: 1.25rem; }
    .p-6 { padding: 1.5rem; }
    .px-2 { padding-left: 0.5rem; padding-right: 0.5rem; }
    .px-2\.5 { padding-left: 0.625rem; padding-right: 0.625rem; }
    .px-3 { padding-left: 0.75rem; padding-right: 0.75rem; }
    .px-3\.5 { padding-left: 0.875rem; padding-right: 0.875rem; }
    .px-4 { padding-left: 1rem; padding-right: 1rem; }
    .px-5 { padding-left: 1.25rem; padding-right: 1.25rem; }
    .px-6 { padding-left: 1.5rem; padding-right: 1.5rem; }
    .py-0\.5 { padding-top: 0.125rem; padding-bottom: 0.125rem; }
    .py-1 { padding-top: 0.25rem; padding-bottom: 0.25rem; }
    .py-1\.5 { padding-top: 0.375rem; padding-bottom: 0.375rem; }
    .py-2 { padding-top: 0.5rem; padding-bottom: 0.5rem; }
    .py-2\.5 { padding-top: 0.625rem; padding-bottom: 0.625rem; }
    .py-3 { padding-top: 0.75rem; padding-bottom: 0.75rem; }
    .py-3\.5 { padding-top: 0.875rem; padding-bottom: 0.875rem; }
    .py-4 { padding-top: 1rem; padding-bottom: 1rem; }
    .py-6 { padding-top: 1.5rem; padding-bottom: 1.5rem; }
    .grid-cols-1 { grid-template-columns: repeat(1, minmax(0, 1fr)); }
    .grid-cols-2 { grid-template-columns: repeat(2, minmax(0, 1fr)); }
    @media (min-width: 640px) {
      .sm\:grid-cols-4 { grid-template-columns: repeat(4, minmax(0, 1fr)); }
      .sm\:flex-row { flex-direction: row; }
      .sm\:items-center { align-items: center; }
      .sm\:inline { display: inline !important; }
      .sm\:p-4 { padding: 1rem; }
      .sm\:p-7 { padding: 1.75rem; }
      .sm\:p-8 { padding: 2rem; }
      .sm\:px-8 { padding-left: 2rem; padding-right: 2rem; }
      .sm\:min-h-\[820px\] { min-height: 820px; }
      .sm\:max-h-\[92vh\] { max-height: 92vh; }
      .sm\:rounded-\[30px\] { border-radius: 30px; }
      .sm\:w-28 { width: 7rem; }
      .sm\:h-28 { height: 7rem; }
      .sm\:text-4xl { font-size: 2.25rem; }
    }
    @media (min-width: 1024px) {
      .lg\:flex { display: flex !important; }
      .lg\:hidden { display: none !important; }
      .lg\:grid-cols-12 { grid-template-columns: repeat(12, minmax(0, 1fr)); }
      .lg\:col-span-5 { grid-column: span 5 / span 5; }
      .lg\:col-span-6 { grid-column: span 6 / span 6; }
      .lg\:col-span-7 { grid-column: span 7 / span 7; }
      .lg\:p-6 { padding: 1.5rem; }
      .lg\:pb-8 { padding-bottom: 2rem; }
    }
    @media (min-width: 1280px) {
      .xl\:grid-cols-12 { grid-template-columns: repeat(12, minmax(0, 1fr)); }
      .xl\:col-span-5 { grid-column: span 5 / span 5; }
      .xl\:col-span-7 { grid-column: span 7 / span 7; }
    }

    /* Custom Scrollbar */
    ::-webkit-scrollbar { width: 6px; height: 6px; }
    ::-webkit-scrollbar-track { background: transparent; }
    ::-webkit-scrollbar-thumb { background: var(--hairline-strong); border-radius: 9999px; }
  </style>
</head>
<body class="min-h-screen flex items-center justify-center p-0 sm:p-4 lg:p-6 relative">

  <!-- AMBIENT LIVING SILK BACKDROP CANVAS -->
  <canvas id="auroraCanvas" class="fixed inset-0 w-full h-full pointer-events-none z-0"></canvas>

  <!-- MACOS DESKTOP STUDIO WINDOW -->
  <div id="macWindow" class="mac-window relative z-10 w-full max-w-[1200px] min-h-screen sm:min-h-[820px] sm:max-h-[92vh] sm:rounded-[30px] flex overflow-hidden">

    <!-- =====================================================================
         LEFT TRANSLUCENT MACOS SIDEBAR (Desktop lg+)
         ===================================================================== -->
    <aside class="mac-sidebar hidden lg:flex w-[256px] shrink-0 flex-col justify-between p-5 select-none">
      <div class="space-y-6">
        <!-- Traffic Lights + App Identity -->
        <div class="flex items-center justify-between px-1">
          <div class="flex items-center gap-2">
            <span class="w-3 h-3 rounded-full bg-[#FF5F57] shadow-inner"></span>
            <span class="w-3 h-3 rounded-full bg-[#FEBC2E] shadow-inner"></span>
            <span class="w-3 h-3 rounded-full bg-[#28C840] shadow-inner"></span>
          </div>
          <span class="text-[11px] font-medium c-3 tracking-tight">v7.0.2</span>
        </div>

        <!-- Brand Capsule -->
        <div class="flex items-center gap-3 px-1.5">
          <div id="sidebarAppIcon" class="w-10 h-10 rounded-[14px] flex items-center justify-center shadow-sm relative overflow-hidden" style="background: var(--primary-bg); color: var(--primary-ink);">
            <svg class="w-5 h-5 relative z-10" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.1" stroke-linecap="round" stroke-linejoin="round">
              <path d="M5 12.55a11 11 0 0 1 14.08 0" />
              <path d="M8.53 16.11a6 6 0 0 1 6.95 0" />
              <circle cx="12" cy="19.2" r="1.2" fill="currentColor" />
            </svg>
          </div>
          <div>
            <div class="font-display font-bold text-[15px] tracking-tight c-1 leading-tight">LanFixer</div>
            <div class="flex items-center gap-1.5 mt-0.5">
              <span id="sidebarStatusDot" class="w-1.5 h-1.5 rounded-full" style="background: var(--ok);"></span>
              <span id="sidebarStatusText" class="text-[11px] font-medium c-2">Connected</span>
            </div>
          </div>
        </div>

        <!-- Sidebar Navigation -->
        <nav class="space-y-5">
          <div class="space-y-1">
            <div class="px-2.5 text-[10px] font-semibold uppercase tracking-wider c-3 mb-1.5">Network</div>
            <button onclick="switchTab('home')" data-nav="home" data-active="true" class="nav-row w-full flex items-center justify-between px-3 py-2.5 rounded-xl text-[13px]">
              <span class="flex items-center gap-2.5">
                <svg class="w-4 h-4 opacity-80" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9"><rect x="3" y="3" width="7" height="7" rx="2"/><rect x="14" y="3" width="7" height="7" rx="2"/><rect x="3" y="14" width="7" height="7" rx="2"/><rect x="14" y="14" width="7" height="7" rx="2"/></svg>
                Overview
              </span>
              <span id="navBadgeHome" class="text-[10px] font-semibold px-2 py-0.5 rounded-full c-ok tabular" style="background: var(--ok-soft);">2 ms</span>
            </button>

            <button onclick="switchTab('speed')" data-nav="speed" class="nav-row w-full flex items-center justify-between px-3 py-2.5 rounded-xl text-[13px]">
              <span class="flex items-center gap-2.5">
                <svg class="w-4 h-4 opacity-80" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9"><path d="M13 2L3 14h9l-1 8 10-12h-9l1-8z"/></svg>
                DNS &amp; Routing
              </span>
            </button>

            <button onclick="switchTab('vault')" data-nav="vault" class="nav-row w-full flex items-center justify-between px-3 py-2.5 rounded-xl text-[13px]">
              <span class="flex items-center gap-2.5">
                <svg class="w-4 h-4 opacity-80" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9"><rect x="3" y="11" width="18" height="11" rx="2.5"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/></svg>
                Portal Sign-In
              </span>
              <span id="navBadgeVault" class="w-2 h-2 rounded-full" style="background: var(--ok);"></span>
            </button>
          </div>

          <div class="space-y-1">
            <div class="px-2.5 text-[10px] font-semibold uppercase tracking-wider c-3 mb-1.5">Care &amp; Safety</div>
            <button onclick="switchTab('tune')" data-nav="tune" class="nav-row w-full flex items-center justify-between px-3 py-2.5 rounded-xl text-[13px]">
              <span class="flex items-center gap-2.5">
                <svg class="w-4 h-4 opacity-80" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9"><line x1="4" y1="21" x2="4" y2="14"/><line x1="4" y1="10" x2="4" y2="3"/><line x1="12" y1="21" x2="12" y2="12"/><line x1="12" y1="8" x2="12" y2="3"/><line x1="20" y1="21" x2="20" y2="16"/><line x1="20" y1="12" x2="20" y2="3"/><circle cx="4" cy="12" r="2"/><circle cx="12" cy="10" r="2"/><circle cx="20" cy="14" r="2"/></svg>
                Tune &amp; Recovery
              </span>
            </button>

            <button onclick="switchTab('history')" data-nav="history" class="nav-row w-full flex items-center justify-between px-3 py-2.5 rounded-xl text-[13px]">
              <span class="flex items-center gap-2.5">
                <svg class="w-4 h-4 opacity-80" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9"><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/></svg>
                Activity &amp; Undo
              </span>
              <span id="navBadgeLedger" class="text-[11px] font-medium c-3 tabular">4</span>
            </button>
          </div>
        </nav>
      </div>

      <!-- Sidebar Footer: Background Guard + Adaptive Power Pill -->
      <div class="space-y-3 pt-4 border-t b-hair">
        <!-- Silent Guard Live Switch -->
        <div class="mac-inset rounded-2xl p-3.5 space-y-2.5">
          <div class="flex items-center justify-between">
            <div>
              <div class="text-xs font-semibold c-1">Silent Guard</div>
              <div id="guardSubLabel" class="text-[11px] c-3">Active · Zero Popups</div>
            </div>
            <button id="guardSwitch" onclick="toggleGuard()" class="mac-switch" data-on="true" aria-label="Toggle Silent Background Guard"></button>
          </div>
          <!-- Battery & Power Telemetry Row (Interactive AC/Battery toggle) -->
          <button onclick="togglePowerSource()" class="w-full pt-2.5 border-t b-hair flex items-center justify-between text-[11px] c-2 hover:c-1 transition cursor-pointer" title="Click to preview AC vs Battery adaptive mode">
            <span class="flex items-center gap-1.5">
              <svg id="powerIcon" class="w-3.5 h-3.5 c-ok" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="2" y="7" width="16" height="10" rx="2"/><line x1="22" y1="11" x2="22" y2="13"/><path d="M11 7l-3 5h4l-2 5"/></svg>
              <span id="powerLabel">AC Power · 96%</span>
            </span>
            <span id="cadenceLabel" class="font-mono text-[10px] c-3">10s</span>
          </button>
        </div>
      </div>
    </aside>

    <!-- =====================================================================
         RIGHT MAIN STUDIO CONTENT AREA
         ===================================================================== -->
    <div class="flex-1 flex flex-col min-w-0 max-h-full overflow-hidden">

      <!-- UNIFIED MACOS TOOLBAR -->
      <header class="px-5 sm:px-8 py-4 border-b b-hair flex items-center justify-between gap-3 shrink-0">
        <!-- Left: Mobile Brand + View Title -->
        <div class="flex items-center gap-3 min-w-0">
          <div class="lg:hidden w-8 h-8 rounded-xl flex items-center justify-center shrink-0" style="background: var(--primary-bg); color: var(--primary-ink);">
            <svg class="w-4 h-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2"><path d="M5 12.55a11 11 0 0 1 14.08 0"/><path d="M8.53 16.11a6 6 0 0 1 6.95 0"/><circle cx="12" cy="19.2" r="1.2" fill="currentColor"/></svg>
          </div>
          <div class="min-w-0">
            <h2 id="toolbarTitle" class="font-display font-bold text-[15px] sm:text-base tracking-tight c-1 truncate">Overview</h2>
          </div>
        </div>

        <!-- Center/Right Controls: Spotlight ⌘K + Scenario Preview + Sound + Theme -->
        <div class="flex items-center gap-2 shrink-0">
          <!-- Spotlight Command Trigger -->
          <button onclick="openSpotlight()" class="btn-glass rounded-full px-3.5 py-1.5 text-xs c-2 flex items-center gap-2.5" title="Open Quick Actions (Ctrl+K)">
            <svg class="w-3.5 h-3.5 c-3" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="8"/><path d="M21 21l-4.35-4.35"/></svg>
            <span class="hidden sm:inline">Quick Actions</span>
            <kbd class="hidden md:inline-block font-mono text-[10px] px-1.5 py-0.5 rounded-md c-3" style="background: var(--card-inset);">⌘K</kbd>
          </button>

          <!-- Live Scenario Preview Selector -->
          <div class="relative">
            <select id="scenarioSelect" onchange="onScenarioSelectChange(this.value)" aria-label="Connection Telemetry & Scenario Simulation"
              class="btn-glass rounded-full pl-3 pr-7 py-1.5 text-xs font-semibold appearance-none focus:outline-none">
              <option value="live" selected>⚡ Live Telemetry</option>
              <option value="healthy">Sim: Connected</option>
              <option value="captive">Sim: Sign-In Needed</option>
              <option value="nodns">Sim: DNS Issue</option>
              <option value="dual">Sim: Wi-Fi Backup</option>
              <option value="apipa">Sim: No IP Lease</option>
            </select>
            <svg class="w-3 h-3 c-3 pointer-events-none absolute right-2.5 top-1/2 -translate-y-1/2" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2"><path d="M6 9l6 6 6-6"/></svg>
          </div>

          <!-- Tactile Sound Toggle -->
          <button id="soundBtn" onclick="toggleSound()" class="btn-glass w-8 h-8 rounded-full flex items-center justify-center" title="Toggle Subtle UI Chimes" aria-label="Toggle Sound">
            <svg id="soundOffIcon" class="w-3.5 h-3.5 c-3" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M11 5L6 9H2v6h4l5 4V5z"/><line x1="23" y1="9" x2="17" y2="15"/><line x1="17" y1="9" x2="23" y2="15"/></svg>
            <svg id="soundOnIcon" class="w-3.5 h-3.5 c-ok hidden" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M11 5L6 9H2v6h4l5 4V5z"/><path d="M15.54 8.46a5 5 0 0 1 0 7.07"/><path d="M19.07 4.93a10 10 0 0 1 0 14.14"/></svg>
          </button>

          <!-- Light / Dark Toggle -->
          <button onclick="toggleMode()" class="btn-glass w-8 h-8 rounded-full flex items-center justify-center" title="Switch Light / Dark Mode" aria-label="Switch Appearance">
            <svg id="iconMoon" class="w-3.5 h-3.5 c-1" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"/></svg>
            <svg id="iconSun" class="w-3.5 h-3.5 c-1 hidden" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="4.5"/><path d="M12 2v2M12 20v2M4.93 4.93l1.41 1.41M17.66 17.66l1.41 1.41M2 12h2M20 12h2M4.93 19.07l1.41-1.41M17.66 6.34l1.41-1.41"/></svg>
          </button>
        </div>
      </header>

      <!-- SCROLLABLE STUDIO STAGE -->
      <div class="flex-1 overflow-y-auto px-5 sm:px-8 py-6 pb-28 lg:pb-8 space-y-6">

        <!-- =================================================================
             VIEW 1: OVERVIEW
             ================================================================= -->
        <section id="view-home" class="app-view view-animate space-y-5">

          <!-- HERO CARD WITH LIVING SPATIAL SIGNAL ORB -->
          <div class="mac-card rounded-[28px] p-6 sm:p-8 relative">
            <div class="flex flex-col md:flex-row items-start md:items-center justify-between gap-7">

              <!-- Left: Spatial Signal Orb + Editorial Status -->
              <div class="flex flex-col sm:flex-row items-start sm:items-center gap-6 min-w-0">
                <!-- Living Canvas Signal Orb -->
                <div class="relative w-24 h-24 sm:w-28 sm:h-28 shrink-0 flex items-center justify-center">
                  <canvas id="orbCanvas" class="w-full h-full block"></canvas>
                  <div id="orbCenterIcon" class="absolute inset-0 flex items-center justify-center pointer-events-none">
                    <!-- Dynamic crisp icon -->
                  </div>
                </div>

                <!-- Headline & Plain-English Summary -->
                <div class="space-y-2.5 min-w-0">
                  <div class="flex flex-wrap items-center gap-2">
                    <span id="heroPill" class="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold" style="background: var(--ok-soft); color: var(--ok);">
                      <span id="heroPillDot" class="w-1.5 h-1.5 rounded-full" style="background: var(--ok);"></span>
                      <span id="heroBadge">Connected &amp; Verified</span>
                    </span>
                    <span id="heroEnvTag" class="text-xs font-medium c-3">Campus Ethernet · 2.5 Gbps</span>
                  </div>

                  <h1 id="heroTitle" class="font-display text-2xl sm:text-[32px] font-bold tracking-tight c-1 leading-[1.15]">
                    Your connection is steady.
                  </h1>
                  <p id="heroDesc" class="text-[13.5px] c-2 leading-relaxed max-w-lg">
                    Wired gigabit link is active with split-horizon campus DNS and verified TLS 1.3 security. Silent Guard is watching in the background.
                  </p>
                </div>
              </div>

              <!-- Right: Primary CTA + Inspect -->
              <div class="flex flex-row md:flex-col items-stretch gap-2.5 w-full md:w-auto shrink-0">
                <button id="btnHeroAction" onclick="runHeroChoreography()" class="btn-primary flex-1 md:flex-none rounded-full px-6 py-3 text-[13px] font-semibold flex items-center justify-center gap-2 whitespace-nowrap">
                  <svg class="w-4 h-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2"><path stroke-linecap="round" stroke-linejoin="round" d="M13 2L3 14h9l-1 8 10-12h-9l1-8z"/></svg>
                  <span id="heroBtnText">Optimize &amp; Verify</span>
                </button>
                <button onclick="openInspector()" class="btn-glass rounded-full px-5 py-2.5 text-xs font-semibold flex items-center justify-center gap-1.5 whitespace-nowrap">
                  <span>7-Layer Check</span>
                  <svg class="w-3.5 h-3.5 c-3" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M9 18l6-6-6-6"/></svg>
                </button>
              </div>
            </div>

            <!-- Live Repair Choreography Strip (Expands smoothly during heal/login) -->
            <div id="choreoBanner" class="hidden mt-6 p-4 rounded-2xl mac-inset space-y-2.5">
              <div class="flex items-center justify-between text-xs">
                <span id="choreoStepText" class="font-semibold c-1">Verifying physical transceiver...</span>
                <span id="choreoStepPct" class="font-mono text-[11px] c-3 tabular">20%</span>
              </div>
              <div class="h-1.5 rounded-full overflow-hidden" style="background: var(--track);">
                <div id="choreoFill" class="h-full rounded-full transition-all duration-300" style="width: 20%; background: var(--ok);"></div>
              </div>
            </div>

            <!-- 4-Step Tactile Connection Journey -->
            <div class="mt-7 pt-6 border-t b-hair grid grid-cols-2 sm:grid-cols-4 gap-3" id="journeyGrid">
              <!-- Populated by JS -->
            </div>
          </div>

          <!-- BENTO GRID: RESPONSE CURVE + ACTIVE INTERFACES & ESSENTIALS -->
          <div class="grid grid-cols-1 xl:grid-cols-12 gap-5">

            <!-- LIVE RESPONSE & STABILITY CHART (7 COLS) -->
            <div class="xl:col-span-7 mac-card rounded-[26px] p-6 flex flex-col justify-between gap-5">
              <div class="flex items-start justify-between gap-4">
                <div>
                  <div class="text-xs font-medium c-3">Live Gateway Response</div>
                  <div class="flex items-baseline gap-2 mt-1 tabular">
                    <span id="metricRtt" class="font-display text-3xl sm:text-4xl font-bold tracking-tight c-1">2.1</span>
                    <span class="text-sm font-medium c-3">ms</span>
                    <span id="metricGrade" class="ml-1.5 text-[11px] font-semibold px-2.5 py-0.5 rounded-full c-ok" style="background: var(--ok-soft);">Grade A+</span>
                  </div>
                </div>
                <div class="flex items-center gap-4 text-right tabular">
                  <div>
                    <div class="text-[11px] c-3">Jitter</div>
                    <div id="metricJitter" class="text-xs font-semibold c-1 mt-0.5">0.4 ms</div>
                  </div>
                  <div>
                    <div class="text-[11px] c-3">Loss</div>
                    <div id="metricLoss" class="text-xs font-semibold c-1 mt-0.5">0%</div>
                  </div>
                  <div>
                    <div class="text-[11px] c-3">Path MTU</div>
                    <div class="text-xs font-semibold c-1 mt-0.5">1500 B</div>
                  </div>
                </div>
              </div>

              <!-- Interactive Bezier Spline Canvas -->
              <div class="relative h-44 w-full rounded-2xl overflow-hidden mac-inset">
                <canvas id="splineCanvas" class="w-full h-full block cursor-crosshair"></canvas>
                <div id="splineTip" class="hidden pointer-events-none absolute top-3 left-3 px-2.5 py-1 rounded-full text-[11px] font-semibold tabular mac-float c-1">
                  2.1 ms
                </div>
                <div id="splineDeadMsg" class="hidden absolute inset-0 flex items-center justify-center text-xs font-medium c-bad">
                  Router unreachable — waiting for IP lease
                </div>
              </div>

              <!-- Quiet Hardware Metadata Bar -->
              <div class="flex flex-wrap items-center justify-between gap-2 text-xs c-2">
                <div class="flex flex-wrap items-center gap-x-4 gap-y-1 font-mono text-[11px] tabular">
                  <span>IP <strong id="metaIp" class="c-1 font-semibold">10.114.230.187/24</strong></span>
                  <span>GW <strong id="metaGw" class="c-1 font-semibold">10.114.230.1</strong></span>
                  <span class="hidden sm:inline">TLS <strong class="c-ok font-semibold">1.3</strong></span>
                </div>
                <button onclick="copyText('A8-5E-45-9C-21-0B', 'Hardware MAC copied')" class="text-xs font-medium c-3 hover:c-1 transition cursor-pointer">
                  Copy MAC
                </button>
              </div>
            </div>

            <!-- RIGHT COLUMN: ACTIVE UPLINKS + QUICK ACTIONS (5 COLS) -->
            <div class="xl:col-span-5 flex flex-col gap-5">

              <!-- ACTIVE INTERFACES COMPARISON -->
              <div class="mac-card rounded-[26px] p-5 space-y-3.5">
                <div class="flex items-center justify-between">
                  <h3 class="font-display font-semibold text-sm c-1">Active Uplinks</h3>
                  <button onclick="switchTab('speed')" class="text-xs font-medium c-blue hover:underline cursor-pointer">Manage</button>
                </div>

                <div id="uplinkCards" class="space-y-2.5">
                  <!-- Populated dynamically by JS -->
                </div>
              </div>

              <!-- ONE-TAP ESSENTIALS -->
              <div class="mac-card rounded-[26px] p-5 flex-1 flex flex-col justify-between gap-3.5">
                <div class="flex items-center justify-between">
                  <h3 class="font-display font-semibold text-sm c-1">Quick Actions</h3>
                  <span class="text-[11px] c-3">Instant · Safe</span>
                </div>
                <div class="grid grid-cols-2 gap-2.5">
                  <button onclick="quickFlush()" class="btn-glass rounded-2xl p-3.5 text-left space-y-1">
                    <div class="flex items-center justify-between">
                      <svg class="w-4 h-4 c-blue" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 12a9 9 0 1 1-9-9c2.52 0 4.93 1 6.74 2.74L21 8"/><path d="M21 3v5h-5"/></svg>
                      <span class="text-[10px] font-mono c-3">18ms</span>
                    </div>
                    <div class="text-xs font-semibold c-1 pt-0.5">Flush Caches</div>
                    <div class="text-[11px] c-3">DNS, ARP &amp; sockets</div>
                  </button>

                  <button onclick="switchTab('speed'); runDnsRace();" class="btn-glass rounded-2xl p-3.5 text-left space-y-1">
                    <div class="flex items-center justify-between">
                      <svg class="w-4 h-4 c-ok" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M13 2L3 14h9l-1 8 10-12h-9l1-8z"/></svg>
                      <span class="text-[10px] font-mono c-3">UDP</span>
                    </div>
                    <div class="text-xs font-semibold c-1 pt-0.5">Race DNS</div>
                    <div class="text-[11px] c-3">Pick fastest server</div>
                  </button>

                  <button onclick="switchTab('vault')" class="btn-glass rounded-2xl p-3.5 text-left space-y-1">
                    <div class="flex items-center justify-between">
                      <svg class="w-4 h-4 c-warn" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="11" width="18" height="11" rx="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/></svg>
                      <span class="text-[10px] font-mono c-ok">DPAPI</span>
                    </div>
                    <div class="text-xs font-semibold c-1 pt-0.5">Portal Vault</div>
                    <div class="text-[11px] c-3">Auto sign-in ready</div>
                  </button>

                  <button onclick="undoLast()" class="btn-glass rounded-2xl p-3.5 text-left space-y-1">
                    <div class="flex items-center justify-between">
                      <svg class="w-4 h-4 c-2" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 7v6h6"/><path d="M21 17a9 9 0 0 0-9-9 9 9 0 0 0-6 2.3L3 13"/></svg>
                      <span class="text-[10px] font-mono c-3">Undo</span>
                    </div>
                    <div class="text-xs font-semibold c-1 pt-0.5">Undo Last</div>
                    <div class="text-[11px] c-3">Instant rollback</div>
                  </button>
                </div>
              </div>

            </div>
          </div>
        </section>

        <!-- =================================================================
             VIEW 2: DNS & ROUTING
             ================================================================= -->
        <section id="view-speed" class="app-view hidden space-y-5">
          <div class="flex flex-wrap items-end justify-between gap-4">
            <div>
              <h1 class="font-display text-2xl font-bold tracking-tight c-1">DNS &amp; Traffic Priority</h1>
              <p class="text-[13px] c-2 mt-1">Benchmark live resolvers over your wired link and balance Ethernet with Wi-Fi.</p>
            </div>
            <button onclick="runDnsRace()" class="btn-primary rounded-full px-5 py-2.5 text-xs font-semibold flex items-center gap-2">
              <svg class="w-3.5 h-3.5" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2"><path d="M13 2L3 14h9l-1 8 10-12h-9l1-8z"/></svg>
              Run Parallel Speed Race
            </button>
          </div>

          <div class="grid grid-cols-1 lg:grid-cols-12 gap-5">
            <!-- DNS Speed Race -->
            <div class="lg:col-span-7 mac-card rounded-[26px] p-6 space-y-6">
              <div class="flex items-center justify-between">
                <div>
                  <h3 class="font-display font-semibold text-sm c-1">Resolver Response Benchmark</h3>
                  <p class="text-xs c-3 mt-0.5">Parallel UDP probes bound strictly to your active interface</p>
                </div>
                <span class="text-[11px] font-medium px-2.5 py-1 rounded-full c-ok" style="background: var(--ok-soft);">Split-Horizon Active</span>
              </div>

              <div id="dnsRaceBars" class="space-y-4">
                <!-- Populated by JS -->
              </div>

              <div class="pt-5 border-t b-hair space-y-3">
                <div class="text-xs font-medium c-3">Resolver Profile</div>
                <div class="seg-wrap w-full grid grid-cols-2 sm:grid-cols-4 rounded-2xl p-1">
                  <button onclick="selectDnsProfile('Adaptive')" data-dns="Adaptive" data-active="true" class="dns-seg seg-item rounded-xl py-2 text-center">Smart Adaptive</button>
                  <button onclick="selectDnsProfile('Cloudflare')" data-dns="Cloudflare" class="dns-seg seg-item rounded-xl py-2 text-center">Cloudflare</button>
                  <button onclick="selectDnsProfile('Hybrid')" data-dns="Hybrid" class="dns-seg seg-item rounded-xl py-2 text-center">Quad9 Hybrid</button>
                  <button onclick="selectDnsProfile('DHCP')" data-dns="DHCP" class="dns-seg seg-item rounded-xl py-2 text-center">Network DHCP</button>
                </div>
              </div>
            </div>

            <!-- Multi-Homed Route Planner -->
            <div class="lg:col-span-5 mac-card rounded-[26px] p-6 flex flex-col justify-between gap-5">
              <div class="space-y-4">
                <div>
                  <h3 class="font-display font-semibold text-sm c-1">Wired &amp; Wi-Fi Balance</h3>
                  <p class="text-xs c-3 mt-0.5">Never drops your hotspot while Ethernet waits for portal login</p>
                </div>

                <div class="space-y-2" id="routeOptionList">
                  <button onclick="selectRouteProfile('Adaptive')" data-rt="Adaptive" class="rt-row w-full btn-glass rounded-2xl p-3.5 text-left flex items-center justify-between gap-3">
                    <div>
                      <div class="text-xs font-semibold c-1">Smart Automatic</div>
                      <div class="text-[11px] c-3 mt-0.5">Ethernet when online · Wi-Fi protected during login</div>
                    </div>
                    <span class="rt-check w-5 h-5 rounded-full flex items-center justify-center text-[11px]"></span>
                  </button>
                  <button onclick="selectRouteProfile('Ethernet')" data-rt="Ethernet" class="rt-row w-full btn-glass rounded-2xl p-3.5 text-left flex items-center justify-between gap-3">
                    <div>
                      <div class="text-xs font-semibold c-1">Always Prefer Ethernet</div>
                      <div class="text-[11px] c-3 mt-0.5">Lock wired gigabit as primary uplink (Metric 10)</div>
                    </div>
                    <span class="rt-check w-5 h-5 rounded-full flex items-center justify-center text-[11px]"></span>
                  </button>
                  <button onclick="selectRouteProfile('Wifi')" data-rt="Wifi" class="rt-row w-full btn-glass rounded-2xl p-3.5 text-left flex items-center justify-between gap-3">
                    <div>
                      <div class="text-xs font-semibold c-1">Prefer Wi-Fi / Hotspot</div>
                      <div class="text-[11px] c-3 mt-0.5">Use wireless for internet while keeping campus LAN</div>
                    </div>
                    <span class="rt-check w-5 h-5 rounded-full flex items-center justify-center text-[11px]"></span>
                  </button>
                  <button onclick="selectRouteProfile('Windows')" data-rt="Windows" class="rt-row w-full btn-glass rounded-2xl p-3.5 text-left flex items-center justify-between gap-3">
                    <div>
                      <div class="text-xs font-semibold c-1">Windows Automatic</div>
                      <div class="text-[11px] c-3 mt-0.5">Restore native Windows metric selection</div>
                    </div>
                    <span class="rt-check w-5 h-5 rounded-full flex items-center justify-center text-[11px]"></span>
                  </button>
                </div>
              </div>

              <!-- Live Route Table Summary -->
              <div id="routeSummaryBox" class="mac-inset rounded-2xl p-3.5 space-y-1.5 font-mono text-[11px] tabular">
                <!-- Populated by JS -->
              </div>
            </div>
          </div>
        </section>

        <!-- =================================================================
             VIEW 3: PORTAL SIGN-IN (APPLE PASSWORDS / 1PASSWORD CALIBER)
             ================================================================= -->
        <section id="view-vault" class="app-view hidden space-y-5">
          <div>
            <h1 class="font-display text-2xl font-bold tracking-tight c-1">Portal Auto Sign-In</h1>
            <p class="text-[13px] c-2 mt-1">Credentials stay encrypted locally in Windows DPAPI and only authenticate to your verified gateway.</p>
          </div>

          <div class="grid grid-cols-1 lg:grid-cols-12 gap-5">
            <!-- Left: Form Card -->
            <div class="lg:col-span-7 mac-card rounded-[26px] p-6 sm:p-7 space-y-5">
              <div class="flex items-center justify-between">
                <div class="flex items-center gap-3">
                  <div class="w-10 h-10 rounded-2xl flex items-center justify-center" style="background: var(--ok-soft);">
                    <svg class="w-5 h-5 c-ok" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="11" width="18" height="11" rx="2.5"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/></svg>
                  </div>
                  <div>
                    <div class="font-display font-semibold text-sm c-1">Encrypted Machine Vault</div>
                    <div class="text-xs c-3">Administrators &amp; LocalSystem ACL locked</div>
                  </div>
                </div>
                <span id="vaultPill" class="text-[11px] font-semibold px-3 py-1 rounded-full c-ok" style="background: var(--ok-soft);">Saved &amp; Ready</span>
              </div>

              <div class="space-y-4">
                <div>
                  <label class="block text-xs font-medium c-2 mb-1.5">Campus Username / Roll Number</label>
                  <input id="vaultUser" type="text" value="2023ugcs042" oninput="syncPassCard()"
                    class="w-full px-4 py-3 rounded-2xl text-sm c-1 mac-inset focus:outline-none focus:ring-2 focus:ring-emerald-500/40 transition" />
                </div>

                <div>
                  <label class="block text-xs font-medium c-2 mb-1.5">Portal Password</label>
                  <div class="relative">
                    <input id="vaultPass" type="password" value="CampusSecurePass2026"
                      class="w-full pl-4 pr-16 py-3 rounded-2xl text-sm c-1 mac-inset focus:outline-none focus:ring-2 focus:ring-emerald-500/40 transition" />
                    <button onclick="togglePasswordEye()" class="absolute right-3.5 top-1/2 -translate-y-1/2 text-xs font-semibold c-3 hover:c-1 cursor-pointer">
                      <span id="eyeLabel">Show</span>
                    </button>
                  </div>
                </div>
              </div>

              <div class="flex flex-wrap items-center justify-between gap-3 pt-2">
                <button onclick="clearVault()" class="text-xs font-semibold c-bad hover:underline cursor-pointer">Remove Saved Login</button>
                <div class="flex items-center gap-2.5">
                  <button onclick="testSignIn()" class="btn-glass rounded-full px-4 py-2.5 text-xs font-semibold">Sign In Now</button>
                  <button onclick="saveVault()" class="btn-primary rounded-full px-5 py-2.5 text-xs font-semibold">Save to Vault</button>
                </div>
              </div>
            </div>

            <!-- Right: Apple Wallet-style Security Pass + Certificate Chain -->
            <div class="lg:col-span-5 flex flex-col gap-5">
              <!-- Premium Tactile Pass Card -->
              <div class="vault-pass rounded-[26px] p-6 space-y-5 relative overflow-hidden">
                <div class="absolute -right-8 -top-8 w-36 h-36 rounded-full opacity-20" style="background: radial-gradient(circle, #34D399, transparent 70%);"></div>
                <div class="flex items-center justify-between">
                  <span class="text-[11px] font-semibold tracking-wider uppercase text-emerald-300/90">Verified Gateway Pass</span>
                  <svg class="w-4 h-4 text-emerald-400" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg>
                </div>
                <div>
                  <div id="passCardUser" class="font-display font-bold text-lg tracking-tight">2023ugcs042</div>
                  <div class="font-mono text-xs text-slate-400 mt-0.5">gateway.nitjsr.ac.in:8888</div>
                </div>
                <div class="pt-4 border-t border-white/10 flex items-center justify-between text-[11px] text-slate-300">
                  <span>TLS 1.3 · Ethernet Bound</span>
                  <span id="certMatchTag" class="text-emerald-300 font-semibold">Pin Matched</span>
                </div>
              </div>

              <!-- Certificate Verification Details -->
              <div class="mac-card rounded-[26px] p-5 space-y-3.5">
                <div class="flex items-center justify-between">
                  <span class="text-xs font-semibold c-1">SHA-256 Certificate Pin</span>
                  <button onclick="copyText('9F:86:D0:81:88:4C:7D:65:9A:2F:EA:A0:C5:5A:D0:15:A3:BF', 'SHA-256 fingerprint copied')" class="text-[11px] font-medium c-blue hover:underline cursor-pointer">Copy</button>
                </div>
                <div class="mac-inset rounded-xl p-3 font-mono text-[11px] c-2 break-all leading-relaxed">
                  9F:86:D0:81:88:4C:7D:65:9A:2F:EA:A0:C5:5A:D0:15:A3:BF
                </div>
                <button onclick="reverifyGatewayCert()" class="w-full btn-glass rounded-full py-2.5 text-xs font-semibold">
                  Re-Verify Gateway Certificate
                </button>
              </div>
            </div>
          </div>
        </section>

        <!-- =================================================================
             VIEW 4: TUNE & RECOVERY
             ================================================================= -->
        <section id="view-tune" class="app-view hidden space-y-5">
          <div>
            <h1 class="font-display text-2xl font-bold tracking-tight c-1">Tune &amp; Recovery</h1>
            <p class="text-[13px] c-2 mt-1">Eliminate Windows network chatter or run a graduated recovery with automatic pre-change backups.</p>
          </div>

          <div class="grid grid-cols-1 lg:grid-cols-12 gap-5">
            <!-- macOS Grouped Settings List -->
            <div class="lg:col-span-6 mac-card rounded-[26px] p-6 space-y-5">
              <div class="flex items-center justify-between gap-3">
                <div>
                  <h3 class="font-display font-semibold text-sm c-1">Careful Network Debloat</h3>
                  <p class="text-xs c-3 mt-0.5">Snapshots your original Windows registry values first</p>
                </div>
                <button onclick="applyTuning()" class="btn-primary rounded-full px-4 py-2 text-xs font-semibold">Apply Selected</button>
              </div>

              <div id="tuneSwitches" class="divide-y b-hair">
                <!-- Populated by JS -->
              </div>
            </div>

            <!-- 6-Tier Graduated Recovery Ladder -->
            <div class="lg:col-span-6 mac-card rounded-[26px] p-6 space-y-4">
              <div class="flex items-center justify-between">
                <div>
                  <h3 class="font-display font-semibold text-sm c-1">6-Tier Recovery Ladder</h3>
                  <p class="text-xs c-3 mt-0.5">Ordered from gentle rollback to full Windows stack rebuild</p>
                </div>
                <span class="text-[11px] font-medium c-ok">Rollback Protected</span>
              </div>

              <div id="recoveryLadder" class="space-y-2.5">
                <!-- Populated by JS -->
              </div>
            </div>
          </div>
        </section>

        <!-- =================================================================
             VIEW 5: ACTIVITY & ROLLBACK
             ================================================================= -->
        <section id="view-history" class="app-view hidden space-y-5">
          <div class="flex flex-wrap items-end justify-between gap-4">
            <div>
              <h1 class="font-display text-2xl font-bold tracking-tight c-1">Activity &amp; Rollback</h1>
              <p class="text-[13px] c-2 mt-1">Every change is logged to your local ledger and can be undone individually.</p>
            </div>
            <div class="flex items-center gap-2">
              <div class="seg-wrap">
                <button onclick="filterActivity('all')" data-act-f="all" data-active="true" class="act-seg seg-item">All</button>
                <button onclick="filterActivity('dns')" data-act-f="dns" class="act-seg seg-item">DNS</button>
                <button onclick="filterActivity('route')" data-act-f="route" class="act-seg seg-item">Routing</button>
                <button onclick="filterActivity('system')" data-act-f="system" class="act-seg seg-item">System</button>
              </div>
              <button onclick="undoLast()" class="btn-glass rounded-full px-4 py-2 text-xs font-semibold">Undo Latest</button>
            </div>
          </div>

          <div class="grid grid-cols-1 lg:grid-cols-12 gap-5">
            <!-- Change Ledger -->
            <div class="lg:col-span-7 mac-card rounded-[26px] p-6 space-y-4">
              <div class="flex items-center justify-between">
                <h3 class="font-display font-semibold text-sm c-1">Change Ledger</h3>
                <span id="ledgerMeta" class="text-xs c-3 tabular">4 reversible entries</span>
              </div>
              <div id="ledgerRows" class="space-y-2.5">
                <!-- Populated by JS -->
              </div>
            </div>

            <!-- Privacy-Safe Diagnostic Bundle -->
            <div class="lg:col-span-5 mac-card rounded-[26px] p-6 flex flex-col justify-between gap-5">
              <div class="space-y-4">
                <div class="flex items-center justify-between gap-3">
                  <div>
                    <h3 class="font-display font-semibold text-sm c-1">Diagnostic Support Bundle</h3>
                    <p class="text-xs c-3 mt-0.5">Sanitizes personal &amp; hardware info automatically</p>
                  </div>
                  <button id="redactSwitch" onclick="togglePrivacy()" class="mac-switch" data-on="true" aria-label="Toggle Strict Privacy Redaction"></button>
                </div>

                <div id="privacyCard" class="mac-inset rounded-2xl p-4 space-y-2.5 font-mono text-[11px] tabular">
                  <!-- Populated by JS -->
                </div>
              </div>

              <button onclick="exportBundle()" class="w-full btn-primary rounded-full py-3 text-xs font-semibold">
                Export Redacted ZIP Bundle
              </button>
            </div>
          </div>
        </section>

      </div>
    </div>
  </div>

  <!-- MOBILE FLOATING GLASS DOCK (Hidden on lg+ desktop) -->
  <nav class="lg:hidden fixed bottom-4 left-1/2 -translate-x-1/2 z-30 mac-float rounded-full p-1.5 flex items-center gap-1 max-w-[94vw] overflow-x-auto" aria-label="Mobile Navigation">
    <button onclick="switchTab('home')" data-dock="home" data-active="true" class="dock-btn rounded-full px-3.5 py-2 text-xs font-semibold shrink-0">Overview</button>
    <button onclick="switchTab('speed')" data-dock="speed" class="dock-btn rounded-full px-3.5 py-2 text-xs font-semibold shrink-0">DNS</button>
    <button onclick="switchTab('vault')" data-dock="vault" class="dock-btn rounded-full px-3.5 py-2 text-xs font-semibold shrink-0">Sign-In</button>
    <button onclick="switchTab('tune')" data-dock="tune" class="dock-btn rounded-full px-3.5 py-2 text-xs font-semibold shrink-0">Tune</button>
    <button onclick="switchTab('history')" data-dock="history" class="dock-btn rounded-full px-3.5 py-2 text-xs font-semibold shrink-0">Activity</button>
  </nav>

  <!-- SLIDE-OVER SHEET: 7-LAYER OSI INSPECTOR -->
  <div id="inspectorSheet" class="hidden fixed inset-0 z-40 bg-black/30 backdrop-blur-sm flex justify-end" onclick="if(event.target===this) closeInspector()">
    <div class="w-full max-w-md h-full p-6 sm:p-7 flex flex-col justify-between overflow-y-auto shadow-2xl border-l b-hair" style="background: var(--card-solid);">
      <div class="space-y-5">
        <div class="flex items-center justify-between">
          <div>
            <h3 class="font-display font-bold text-lg c-1">7-Layer Health Inspector</h3>
            <p class="text-xs c-3 mt-0.5">End-to-end verification from cable to internet</p>
          </div>
          <button onclick="closeInspector()" class="btn-glass w-8 h-8 rounded-full flex items-center justify-center text-xs">✕</button>
        </div>
        <div id="inspectorList" class="space-y-2.5">
          <!-- Populated by JS -->
        </div>
      </div>

      <div class="pt-5 border-t b-hair flex items-center gap-2.5">
        <button onclick="closeInspector(); runHeroChoreography();" class="flex-1 btn-primary rounded-full py-3 text-xs font-semibold">Run 7-Layer Repair</button>
        <button onclick="closeInspector()" class="btn-glass rounded-full px-5 py-3 text-xs font-semibold">Done</button>
      </div>
    </div>
  </div>

  <!-- MACOS SPOTLIGHT COMMAND PALETTE (⌘K / Ctrl+K) -->
  <div id="spotlightBackdrop" class="hidden fixed inset-0 z-50 bg-black/35 backdrop-blur-sm flex items-start justify-center pt-20 sm:pt-28 px-4" onclick="if(event.target===this) closeSpotlight()">
    <div class="mac-float modal-pop w-full max-w-lg rounded-[24px] overflow-hidden border b-hair" style="background: var(--card-solid);">
      <div class="flex items-center gap-3 px-5 py-4 border-b b-hair">
        <svg class="w-4 h-4 c-3 shrink-0" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="8"/><path d="M21 21l-4.35-4.35"/></svg>
        <input id="spotlightInput" type="text" placeholder="Search actions, views, or simulate a network state..." oninput="renderSpotlight()"
          class="w-full bg-transparent text-sm c-1 focus:outline-none placeholder:text-slate-400" />
        <kbd class="font-mono text-[10px] px-2 py-0.5 rounded-md c-3" style="background: var(--card-inset);">ESC</kbd>
      </div>
      <div id="spotlightResults" class="p-2 max-h-72 overflow-y-auto space-y-0.5">
        <!-- Populated by JS -->
      </div>
    </div>
  </div>

  <!-- MACOS CONFIRMATION SHEET (FOR RECOVERY TIERS) -->
  <div id="confirmBackdrop" class="hidden fixed inset-0 z-50 bg-black/35 backdrop-blur-sm flex items-center justify-center p-4" onclick="if(event.target===this) closeConfirm()">
    <div class="mac-float modal-pop w-full max-w-sm rounded-[26px] p-6 space-y-5 border b-hair" style="background: var(--card-solid);">
      <div class="space-y-2">
        <span id="confBadge" class="inline-block text-[11px] font-semibold px-2.5 py-0.5 rounded-full">Step 3</span>
        <h3 id="confTitle" class="font-display font-bold text-lg c-1">Confirm Action</h3>
        <p id="confDesc" class="text-xs c-2 leading-relaxed">A full pre-change snapshot is saved automatically before proceeding.</p>
      </div>
      <div id="confTypedBox" class="hidden">
        <label class="block text-xs c-3 mb-1.5">Type <strong class="c-1">yes</strong> to confirm</label>
        <input id="confInput" type="text" placeholder="yes" class="w-full px-3.5 py-2.5 rounded-xl text-sm c-1 mac-inset focus:outline-none" />
      </div>
      <div class="flex items-center justify-end gap-2">
        <button onclick="closeConfirm()" class="btn-glass rounded-full px-4 py-2.5 text-xs font-semibold">Cancel</button>
        <button onclick="confirmRecoveryAction()" class="btn-primary rounded-full px-5 py-2.5 text-xs font-semibold">Continue</button>
      </div>
    </div>
  </div>

  <!-- SUBTLE FLOATING TOAST -->
  <div id="toast" class="fixed top-6 left-1/2 -translate-x-1/2 -translate-y-24 opacity-0 z-50 transition-all duration-300 pointer-events-none">
    <div class="mac-float rounded-full px-5 py-2.5 flex items-center gap-2.5">
      <span id="toastDot" class="w-2 h-2 rounded-full" style="background: var(--ok);"></span>
      <span id="toastMsg" class="text-xs font-semibold c-1">Done</span>
    </div>
  </div>

  <script>
    // =========================================================================
    // APP STATE & DATA MODELS
    // =========================================================================
    let appMode = 'light';
    let currentTab = 'home';
    let currentScenario = 'healthy';
    let guardOn = true;
    let onBattery = false;
    let soundOn = false;
    let strictPrivacy = true;
    let activityFilter = 'all';
    let activeDnsProfile = 'Adaptive';
    let activeRouteProfile = 'Adaptive';
    let pendingRecovery = null;
    let hoverIdx = -1;
    let rttSeries = Array.from({ length: 44 }, () => 2.1 + (Math.random() - 0.5) * 0.9);

    const TAB_TITLES = {
      home: 'Overview',
      speed: 'DNS & Traffic Priority',
      vault: 'Portal Auto Sign-In',
      tune: 'Tune & Recovery',
      history: 'Activity & Rollback'
    };

    const SCENARIOS = {
      healthy: {
        tone: 'ok',
        short: 'Connected',
        badge: 'Connected & Verified',
        env: 'Campus Ethernet · 2.5 Gbps',
        title: 'Your connection is steady.',
        desc: 'Wired gigabit link is active with split-horizon campus DNS and verified TLS 1.3 security. Silent Guard is watching in the background.',
        btn: 'Optimize & Verify',
        action: 'heal',
        rttBase: 2.1,
        grade: 'Grade A+',
        loss: '0%',
        ip: '10.114.230.187/24',
        gw: '10.114.230.1',
        ethPrimary: true,
        hops: [
          { label: 'Adapter', val: '2.5G Wired', tone: 'ok' },
          { label: 'Router', val: '10.114.230.1', tone: 'ok' },
          { label: 'Smart DNS', val: '1.1.1.1 · 4ms', tone: 'ok' },
          { label: 'Internet', val: 'TLS 1.3 OK', tone: 'ok' }
        ],
        layers: [
          { n: 1, name: 'Physical Link', tone: 'ok', detail: 'Realtek 2.5GbE running at full speed with AC power-sleep disabled.' },
          { n: 2, name: 'IPv4 Lease', tone: 'ok', detail: 'DHCP lease 10.114.230.187/24 active (254 usable hosts).' },
          { n: 3, name: 'Router & ARP', tone: 'ok', detail: 'Gateway 10.114.230.1 responds in 2 ms with spoofing lock.' },
          { n: 4, name: 'Domain Lookup', tone: 'ok', detail: 'Cloudflare 1.1.1.1 for web; campus DNS for internal ERPs.' },
          { n: 5, name: 'Internet Probe', tone: 'ok', detail: 'HTTP 204 check verified directly over Ethernet.' },
          { n: 6, name: 'TLS Security', tone: 'ok', detail: 'Direct TLS 1.3 handshake verified with trusted CA chain.' },
          { n: 7, name: 'Portal Access', tone: 'ok', detail: 'Authenticated with unrestricted egress.' }
        ]
      },
      captive: {
        tone: 'warn',
        short: 'Sign-In Needed',
        badge: 'Sign-In Required',
        env: 'Campus Portal · 10.114.0.5',
        title: 'One tap to unlock the network.',
        desc: 'Your campus gateway is asking for portal login. Saved DPAPI credentials are ready for silent sign-in while Wi-Fi stays protected.',
        btn: 'Sign In Automatically',
        action: 'login',
        rttBase: 3.3,
        grade: 'Grade A',
        loss: '0%',
        ip: '10.114.230.187/24',
        gw: '10.114.230.1',
        ethPrimary: false,
        hops: [
          { label: 'Adapter', val: '2.5G Wired', tone: 'ok' },
          { label: 'Router', val: '10.114.230.1', tone: 'ok' },
          { label: 'Smart DNS', val: 'Campus Ready', tone: 'ok' },
          { label: 'Internet', val: 'Login Waiting', tone: 'warn' }
        ],
        layers: [
          { n: 1, name: 'Physical Link', tone: 'ok', detail: 'Ethernet carrier active at 2.5 Gbps.' },
          { n: 2, name: 'IPv4 Lease', tone: 'ok', detail: 'Valid campus IP 10.114.230.187/24 acquired.' },
          { n: 3, name: 'Router & ARP', tone: 'ok', detail: 'Direct /32 route to portal 10.114.0.5 pinned on Ethernet.' },
          { n: 4, name: 'Domain Lookup', tone: 'ok', detail: 'Campus DNS responding cleanly.' },
          { n: 5, name: 'Internet Probe', tone: 'warn', detail: 'Redirected to https://10.114.0.5:8888/.' },
          { n: 6, name: 'TLS Security', tone: 'warn', detail: 'Outbound HTTPS paused until portal authentication.' },
          { n: 7, name: 'Portal Access', tone: 'warn', detail: 'Encrypted vault ready to sign in as 2023ugcs042.' }
        ]
      },
      nodns: {
        tone: 'bad',
        short: 'DNS Issue',
        badge: 'DNS Unresponsive',
        env: 'Campus Ethernet · 2.5 Gbps',
        title: 'Websites aren’t resolving.',
        desc: 'Your cable and router are healthy, but the network’s DNS server stopped answering. Tap below to race and switch to the fastest live server.',
        btn: 'Repair DNS Now',
        action: 'heal',
        rttBase: 4.5,
        grade: 'Grade B',
        loss: '0%',
        ip: '10.114.230.187/24',
        gw: '10.114.230.1',
        ethPrimary: true,
        hops: [
          { label: 'Adapter', val: '2.5G Wired', tone: 'ok' },
          { label: 'Router', val: '10.114.230.1', tone: 'ok' },
          { label: 'Smart DNS', val: 'Timed Out', tone: 'bad' },
          { label: 'Internet', val: 'Blocked by DNS', tone: 'bad' }
        ],
        layers: [
          { n: 1, name: 'Physical Link', tone: 'ok', detail: 'Ethernet hardware healthy at 2.5 Gbps.' },
          { n: 2, name: 'IPv4 Lease', tone: 'ok', detail: 'Valid IPv4 lease active.' },
          { n: 3, name: 'Router & ARP', tone: 'ok', detail: 'Gateway answering normally.' },
          { n: 4, name: 'Domain Lookup', tone: 'bad', detail: '172.16.1.2 timed out across 3 scoped UDP probes.' },
          { n: 5, name: 'Internet Probe', tone: 'bad', detail: 'Hostnames fail to resolve; raw IP transit alive.' },
          { n: 6, name: 'TLS Security', tone: 'ok', detail: 'Direct TLS 1.3 to 1.1.1.1 verified healthy.' },
          { n: 7, name: 'Portal Access', tone: 'warn', detail: 'Awaiting DNS failover.' }
        ]
      },
      dual: {
        tone: 'blue',
        short: 'Wi-Fi Backup',
        badge: 'Protected on Wi-Fi',
        env: 'Hotspot Primary · LAN Standby',
        title: 'Seamlessly kept online via Wi-Fi.',
        desc: 'Because Ethernet is waiting for campus sign-in, LanFixer automatically routed traffic through your wireless hotspot so nothing drops.',
        btn: 'Sign In & Use Wired',
        action: 'login',
        rttBase: 3.1,
        grade: 'Grade A+',
        loss: '0%',
        ip: '192.168.43.112/24',
        gw: '192.168.43.1',
        ethPrimary: false,
        hops: [
          { label: 'Adapter', val: 'Wi-Fi + LAN', tone: 'ok' },
          { label: 'Priority', val: 'Wi-Fi First', tone: 'blue' },
          { label: 'Smart DNS', val: 'Multi-Homed', tone: 'ok' },
          { label: 'Internet', val: 'Online (Wi-Fi)', tone: 'ok' }
        ],
        layers: [
          { n: 1, name: 'Physical Link', tone: 'ok', detail: 'Both Ethernet (2.5G) and Wi-Fi (866 Mbps) active.' },
          { n: 2, name: 'IPv4 Lease', tone: 'ok', detail: 'Valid leases present on both adapters.' },
          { n: 3, name: 'Router & ARP', tone: 'ok', detail: 'Wi-Fi promoted (Metric 15); LAN pinned to portal only.' },
          { n: 4, name: 'Domain Lookup', tone: 'ok', detail: 'Multi-homed DNS active across uplinks.' },
          { n: 5, name: 'Internet Probe', tone: 'ok', detail: 'Verified online over secondary Wi-Fi uplink.' },
          { n: 6, name: 'TLS Security', tone: 'ok', detail: 'TLS 1.3 verified cleanly.' },
          { n: 7, name: 'Portal Access', tone: 'warn', detail: 'Ethernet portal ready whenever you sign in.' }
        ]
      },
      apipa: {
        tone: 'bad',
        short: 'No IP Lease',
        badge: 'No IP Address',
        env: 'DHCP Timeout · APIPA',
        title: 'Waiting for a fresh address.',
        desc: 'Windows fell back to a self-assigned 169.254 address after DHCP timed out. LanFixer will enforce RFC 2131 broadcast renewal.',
        btn: 'Renew IP Lease',
        action: 'heal',
        rttBase: -1,
        grade: 'Offline',
        loss: '100%',
        ip: '169.254.84.12/16',
        gw: 'None',
        ethPrimary: true,
        hops: [
          { label: 'Adapter', val: '1 Gbps Link', tone: 'ok' },
          { label: 'Router', val: 'No IP Lease', tone: 'bad' },
          { label: 'Smart DNS', val: 'Unavailable', tone: 'bad' },
          { label: 'Internet', val: 'Offline', tone: 'bad' }
        ],
        layers: [
          { n: 1, name: 'Physical Link', tone: 'ok', detail: 'Ethernet cable detected at 1 Gbps.' },
          { n: 2, name: 'IPv4 Lease', tone: 'bad', detail: 'Self-assigned APIPA 169.254.84.12 active.' },
          { n: 3, name: 'Router & ARP', tone: 'bad', detail: 'No default gateway assigned.' },
          { n: 4, name: 'Domain Lookup', tone: 'bad', detail: 'No DNS servers received from DHCP.' },
          { n: 5, name: 'Internet Probe', tone: 'bad', detail: 'Offline until DHCP completes.' },
          { n: 6, name: 'TLS Security', tone: 'bad', detail: 'Offline.' },
          { n: 7, name: 'Portal Access', tone: 'bad', detail: 'Offline.' }
        ]
      }
    };

    const DNS_SERVERS = [
      { ip: '1.1.1.1', name: 'Cloudflare', note: 'Fastest · Encrypted', ms: 4.1 },
      { ip: '172.16.1.2', name: 'Campus Intranet', note: 'Split-Horizon', ms: 6.4 },
      { ip: '9.9.9.9', name: 'Quad9 Security', note: 'Malware Blocking', ms: 10.8 },
      { ip: '8.8.8.8', name: 'Google Public', note: 'Global Backup', ms: 14.2 }
    ];

    const TUNE_SWITCHES = [
      { id: 'p2p', title: 'Stop P2P Update Seeding', desc: 'Prevents Windows Update from uploading files to external peers.', on: true },
      { id: 'throttle', title: 'Disable Media Packet Throttling', desc: 'Removes Windows’ artificial cap during music, calls, or gaming.', on: true },
      { id: 'llmnr', title: 'Shield Against LAN Name Spoofing', desc: 'Disables legacy LLMNR & WPAD broadcasts on shared hostel networks.', on: true },
      { id: 'tunnels', title: 'Disable Legacy IPv6 Tunnels', desc: 'Stops 20-second hangs caused by Teredo and ISATAP fallback loops.', on: true },
      { id: 'usb', title: 'Keep USB Ethernet Awake on AC', desc: 'Eliminates adapter sleep drops on wall power while sparing battery.', on: true }
    ];

    const RECOVERY_TIERS = [
      { tier: 1, badge: 'Gentle', tone: 'ok', title: 'Apply Low-Latency Tuning', desc: 'Applies selected switches with automatic pre-change snapshot.', confirm: false },
      { tier: 2, badge: 'Safe Rollback', tone: 'blue', title: 'Restore Original Windows Settings', desc: 'Reverts all DNS, routing, power, and registry snapshots cleanly.', confirm: true },
      { tier: 3, badge: 'Standard', tone: 'warn', title: 'Refresh Network Stack (5-Stage)', desc: 'Resets Winsock, clears dead proxies, and runs full 7-layer repair.', confirm: true },
      { tier: 4, badge: 'Deep', tone: 'warn', title: 'Deep Stack Rebuild (10-Stage)', desc: 'Rebuilds 64/32-bit Winsock, TCP heuristics, firewall & NCSI.', confirm: true },
      { tier: 5, badge: 'Hardware', tone: 'bad', title: 'Reinstall All Network Adapters', desc: 'Cycles Wi-Fi, Ethernet, Bluetooth, and USB transceivers cleanly.', confirm: true, typed: true },
      { tier: 6, badge: 'Reboot', tone: 'bad', title: 'Clean Windows Stack Wipe (netcfg -d)', desc: 'Native Windows factory network reinstall. Requires restart.', confirm: true, typed: true }
    ];

    let LEDGER = [
      { id: '8f3a', cat: 'route', time: 'Just now', title: 'Prioritized Wired Ethernet', detail: 'Set Ethernet ahead of Wi-Fi while online (Metric 10 vs 40)' },
      { id: '4b91', cat: 'dns', time: '2m ago', title: 'Configured Split-Horizon DNS', detail: 'Web via Cloudflare 1.1.1.1 · Campus ERPs via 172.16.1.2' },
      { id: '2c70', cat: 'system', time: '3m ago', title: 'Locked Router ARP Address', detail: 'Protected gateway 10.114.230.1 against hostel LAN spoofing' },
      { id: '1a09', cat: 'system', time: '6m ago', title: 'Disabled AC USB Sleep', detail: 'USB Ethernet stays awake on wall power; battery policy untouched' }
    ];

    // =========================================================================
    // SUBTLE WEB AUDIO TACTILE MICRO-CHIMES (OFF BY DEFAULT, OPT-IN)
    // =========================================================================
    let audioCtx = null;
    function chime(freq = 640, dur = 0.045) {
      if (!soundOn) return;
      try {
        if (!audioCtx) audioCtx = new (window.AudioContext || window.webkitAudioContext)();
        const o = audioCtx.createOscillator();
        const g = audioCtx.createGain();
        o.type = 'sine';
        o.frequency.setValueAtTime(freq, audioCtx.currentTime);
        o.frequency.exponentialRampToValueAtTime(freq * 1.15, audioCtx.currentTime + dur);
        g.gain.setValueAtTime(0.025, audioCtx.currentTime);
        g.gain.exponentialRampToValueAtTime(0.0001, audioCtx.currentTime + dur);
        o.connect(g); g.connect(audioCtx.destination);
        o.start(); o.stop(audioCtx.currentTime + dur);
      } catch {}
    }

    function toggleSound() {
      soundOn = !soundOn;
      document.getElementById('soundOffIcon').classList.toggle('hidden', soundOn);
      document.getElementById('soundOnIcon').classList.toggle('hidden', !soundOn);
      if (soundOn) chime(720, 0.06);
      showToast(soundOn ? 'Subtle UI chimes enabled' : 'UI chimes muted');
    }

    // =========================================================================
    // POINTER-TRACKING SPECULAR GLASS LIGHT EFFECT
    // =========================================================================
    document.addEventListener('pointermove', e => {
      document.querySelectorAll('.mac-card').forEach(card => {
        const r = card.getBoundingClientRect();
        card.style.setProperty('--mx', (e.clientX - r.left) + 'px');
        card.style.setProperty('--my', (e.clientY - r.top) + 'px');
      });
    });

    // =========================================================================
    // NAVIGATION & THEME
    // =========================================================================
    function switchTab(tab) {
      currentTab = tab;
      chime(560, 0.035);
      document.getElementById('toolbarTitle').textContent = TAB_TITLES[tab];

      document.querySelectorAll('.app-view').forEach(v => {
        v.classList.add('hidden');
        v.classList.remove('view-animate');
      });
      const el = document.getElementById('view-' + tab);
      el.classList.remove('hidden');
      void el.offsetWidth;
      el.classList.add('view-animate');

      document.querySelectorAll('.nav-row').forEach(b => b.setAttribute('data-active', b.dataset.nav === tab ? 'true' : 'false'));
      document.querySelectorAll('.dock-btn').forEach(b => b.setAttribute('data-active', b.dataset.dock === tab ? 'true' : 'false'));

      if (tab === 'home') setTimeout(() => { resizeSpline(); resizeOrb(); }, 25);
    }

    function toggleMode() {
      appMode = appMode === 'light' ? 'dark' : 'light';
      document.documentElement.setAttribute('data-mode', appMode);
      document.getElementById('iconMoon').classList.toggle('hidden', appMode === 'dark');
      document.getElementById('iconSun').classList.toggle('hidden', appMode === 'light');
      chime(620, 0.04);
      drawSpline();
    }

    function toggleGuard() {
      guardOn = !guardOn;
      document.getElementById('guardSwitch').setAttribute('data-on', guardOn ? 'true' : 'false');
      document.getElementById('guardSubLabel').textContent = guardOn ? 'Active · Zero Popups' : 'Paused';
      chime(guardOn ? 740 : 420, 0.05);
      showToast(guardOn ? 'Silent Background Guard enabled' : 'Silent Guard paused');
    }

    function togglePowerSource() {
      onBattery = !onBattery;
      document.getElementById('powerLabel').textContent = onBattery ? 'Battery · 78%' : 'AC Power · 96%';
      document.getElementById('cadenceLabel').textContent = onBattery ? '20s Eco' : '10s';
      document.getElementById('powerIcon').style.color = onBattery ? 'var(--warn)' : 'var(--ok)';
      showToast(onBattery ? 'Battery Eco Mode: Polling slowed to 20s & USB DC preserved' : 'AC Wall Power: Low-latency Ethernet mode active');
    }

    // =========================================================================
    // TONE COLOR HELPERS
    // =========================================================================
    function toneVar(tone) {
      return tone === 'ok' ? 'var(--ok)' : tone === 'warn' ? 'var(--warn)' : tone === 'blue' ? 'var(--blue)' : 'var(--bad)';
    }
    function toneSoftVar(tone) {
      return tone === 'ok' ? 'var(--ok-soft)' : tone === 'warn' ? 'var(--warn-soft)' : tone === 'blue' ? 'var(--blue-soft)' : 'var(--bad-soft)';
    }
    function toneHex(tone) {
      const d = appMode === 'dark';
      if (tone === 'ok') return d ? '#34D399' : '#0E9F6E';
      if (tone === 'warn') return d ? '#FBBF24' : '#D97706';
      if (tone === 'blue') return d ? '#60A5FA' : '#2563EB';
      return d ? '#F87171' : '#E02424';
    }

    // =========================================================================
    // SCENARIO STATE ENGINE
    // =========================================================================
    function setScenario(key) {
      currentScenario = key;
      document.getElementById('scenarioSelect').value = key;
      const s = SCENARIOS[key];
      const col = toneVar(s.tone);
      const soft = toneSoftVar(s.tone);

      document.getElementById('sidebarStatusDot').style.background = col;
      document.getElementById('sidebarStatusText').textContent = s.short;
      document.getElementById('heroPill').style.background = soft;
      document.getElementById('heroPill').style.color = col;
      document.getElementById('heroPillDot').style.background = col;
      document.getElementById('heroBadge').textContent = s.badge;
      document.getElementById('heroEnvTag').textContent = s.env;
      document.getElementById('heroTitle').textContent = s.title;
      document.getElementById('heroDesc').textContent = s.desc;
      document.getElementById('heroBtnText').textContent = s.btn;
      document.getElementById('metaIp').textContent = s.ip;
      document.getElementById('metaGw').textContent = s.gw;
      document.getElementById('metricLoss').textContent = s.loss;

      const gradeEl = document.getElementById('metricGrade');
      gradeEl.textContent = s.grade;
      gradeEl.style.color = col;
      gradeEl.style.background = soft;

      const badgeHome = document.getElementById('navBadgeHome');
      badgeHome.style.color = col;
      badgeHome.style.background = soft;
      if (s.rttBase < 0) {
        badgeHome.textContent = 'Off';
        document.getElementById('metricRtt').textContent = '—';
        document.getElementById('metricJitter').textContent = '—';
      }

      document.getElementById('splineDeadMsg').classList.toggle('hidden', s.rttBase >= 0);

      // Orb center icon
      const orbIcon = s.tone === 'ok'
        ? `<svg class="w-7 h-7" style="color:${col}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"/></svg>`
        : s.tone === 'warn'
        ? `<svg class="w-7 h-7" style="color:${col}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="11" width="18" height="11" rx="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/></svg>`
        : s.tone === 'blue'
        ? `<svg class="w-7 h-7" style="color:${col}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12.55a11 11 0 0 1 14.08 0"/><path d="M8.53 16.11a6 6 0 0 1 6.95 0"/><circle cx="12" cy="19.5" r="1" fill="currentColor"/></svg>`
        : `<svg class="w-7 h-7" style="color:${col}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.3" stroke-linecap="round" stroke-linejoin="round"><path d="M12 9v4"/><path d="M12 17h.01"/><circle cx="12" cy="12" r="9"/></svg>`;
      document.getElementById('orbCenterIcon').innerHTML = orbIcon;

      // 4-step Connection Journey
      document.getElementById('journeyGrid').innerHTML = s.hops.map(h => `
        <button onclick="openInspector()" class="btn-glass rounded-2xl p-3.5 text-left flex items-center gap-3">
          <span class="w-2.5 h-2.5 rounded-full shrink-0" style="background:${toneVar(h.tone)}; box-shadow: 0 0 0 4px ${toneSoftVar(h.tone)};"></span>
          <div class="min-w-0">
            <div class="text-[11px] c-3">${h.label}</div>
            <div class="text-xs font-semibold c-1 truncate mt-0.5">${h.val}</div>
          </div>
        </button>
      `).join('');

      // Active Uplinks Comparison Cards
      document.getElementById('uplinkCards').innerHTML = `
        <div class="mac-inset rounded-2xl p-3.5 flex items-center justify-between gap-3">
          <div class="flex items-center gap-3 min-w-0">
            <div class="w-9 h-9 rounded-xl flex items-center justify-center shrink-0" style="background:${s.ethPrimary ? 'var(--ok-soft)' : 'var(--card-bg)'};">
              <svg class="w-4 h-4 ${s.ethPrimary ? 'c-ok' : 'c-2'}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="2" y="4" width="20" height="16" rx="3"/><path d="M8 10h8M10 14h4"/></svg>
            </div>
            <div class="min-w-0">
              <div class="text-xs font-semibold c-1 truncate">Ethernet · 2.5 Gbps</div>
              <div class="font-mono text-[11px] c-3 truncate">${s.ip}</div>
            </div>
          </div>
          <span class="text-[10px] font-semibold px-2.5 py-1 rounded-full shrink-0" style="background:${s.ethPrimary ? 'var(--ok-soft)' : 'var(--warn-soft)'}; color:${s.ethPrimary ? 'var(--ok)' : 'var(--warn)'};">
            ${s.ethPrimary ? 'Primary · M10' : 'Standby · M50'}
          </span>
        </div>

        <div class="mac-inset rounded-2xl p-3.5 flex items-center justify-between gap-3">
          <div class="flex items-center gap-3 min-w-0">
            <div class="w-9 h-9 rounded-xl flex items-center justify-center shrink-0" style="background:${!s.ethPrimary ? 'var(--blue-soft)' : 'var(--card-bg)'};">
              <svg class="w-4 h-4 ${!s.ethPrimary ? 'c-blue' : 'c-2'}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M5 12.55a11 11 0 0 1 14.08 0"/><path d="M8.53 16.11a6 6 0 0 1 6.95 0"/><circle cx="12" cy="19.5" r="1" fill="currentColor"/></svg>
            </div>
            <div class="min-w-0">
              <div class="text-xs font-semibold c-1 truncate">Wi-Fi · 866 Mbps</div>
              <div class="font-mono text-[11px] c-3 truncate">192.168.43.112/24</div>
            </div>
          </div>
          <span class="text-[10px] font-semibold px-2.5 py-1 rounded-full shrink-0" style="background:${!s.ethPrimary ? 'var(--blue-soft)' : 'var(--track)'}; color:${!s.ethPrimary ? 'var(--blue)' : 'var(--ink-2)'};">
            ${!s.ethPrimary ? 'Primary · M15' : 'Backup · M40'}
          </span>
        </div>
      `;

      // 7-Layer Inspector Sheet
      document.getElementById('inspectorList').innerHTML = s.layers.map(l => `
        <div class="mac-inset rounded-2xl p-4 space-y-1">
          <div class="flex items-center justify-between">
            <span class="text-xs font-semibold c-1">Layer ${l.n} · ${l.name}</span>
            <span class="text-[10px] font-semibold px-2 py-0.5 rounded-full" style="background:${toneSoftVar(l.tone)}; color:${toneVar(l.tone)};">
              ${l.tone === 'ok' ? 'Healthy' : l.tone === 'warn' ? 'Attention' : 'Issue'}
            </span>
          </div>
          <p class="text-xs c-2 leading-relaxed">${l.detail}</p>
        </div>
      `).join('');

      drawSpline();
    }

    // =========================================================================
    // LIVE 7-LAYER REPAIR CHOREOGRAPHY
    // =========================================================================
    let isChoreoRunning = false;
    function runHeroChoreography() {
      if (isChoreoRunning) return;
      isChoreoRunning = true;
      chime(660, 0.06);

      const isLogin = SCENARIOS[currentScenario].action === 'login';
      const cmd = isLogin ? 'login' : 'repair';

      // Dispatch real Windows network defense operation asynchronously
      fetch('/api/action', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ cmd })
      }).then(r => r.json()).then(res => {
        showToast(res.result);
        if (typeof pollLiveStatus === 'function') pollLiveStatus();
      }).catch(err => {
        showToast('Action note: ' + err.message);
      });
      const steps = isLogin
        ? [
            { pct: 25, text: 'Pinning direct Ethernet route to gateway 10.114.0.5...' },
            { pct: 55, text: 'Verifying TLS 1.3 SHA-256 portal fingerprint...' },
            { pct: 82, text: 'Submitting encrypted DPAPI credentials...' },
            { pct: 100, text: 'Authenticated! Switching to fastest DNS...' }
          ]
        : [
            { pct: 20, text: 'Verifying adapter hardware & AC power shield...' },
            { pct: 45, text: 'Checking IPv4 DHCP lease & locking router ARP...' },
            { pct: 75, text: 'Racing DNS resolvers over Ethernet...' },
            { pct: 100, text: 'All 7 OSI layers verified healthy.' }
          ];

      const banner = document.getElementById('choreoBanner');
      const txt = document.getElementById('choreoStepText');
      const pct = document.getElementById('choreoStepPct');
      const fill = document.getElementById('choreoFill');
      banner.classList.remove('hidden');

      steps.forEach((st, idx) => {
        setTimeout(() => {
          txt.textContent = st.text;
          pct.textContent = st.pct + '%';
          fill.style.width = st.pct + '%';
          if (idx === steps.length - 1) {
            setTimeout(() => {
              banner.classList.add('hidden');
              fill.style.width = '0%';
              isChoreoRunning = false;
              setScenario('healthy');
              addLedger(isLogin ? 'system' : 'dns',
                isLogin ? 'Signed Into Campus Portal' : 'Completed 7-Layer Stabilization',
                isLogin ? 'Authenticated over TLS 1.3 via encrypted DPAPI vault' : 'Verified adapter, lease, gateway ARP & fastest DNS');
              chime(880, 0.08);
              showToast(isLogin ? 'Signed in automatically — You’re online' : 'Connection stabilized & verified');
            }, 420);
          }
        }, idx * 420);
      });
    }

    // =========================================================================
    // DNS, ROUTING, VAULT, TUNE & LEDGER ACTIONS
    // =========================================================================
    function renderDnsRace() {
      const maxVal = Math.max(20, ...DNS_SERVERS.map(d => d.ms));
      document.getElementById('dnsRaceBars').innerHTML = DNS_SERVERS.map((d, i) => {
        const w = Math.max(12, Math.round((d.ms / maxVal) * 100));
        return `
          <div class="space-y-1.5">
            <div class="flex items-center justify-between text-xs">
              <div class="flex items-center gap-2">
                <span class="font-semibold c-1">${d.name}</span>
                <span class="font-mono text-[11px] c-3">${d.ip}</span>
                ${i === 0 ? '<span class="text-[10px] font-semibold px-2 py-0.5 rounded-full c-ok" style="background:var(--ok-soft);">Fastest</span>' : `<span class="hidden sm:inline text-[11px] c-3">· ${d.note}</span>`}
              </div>
              <span class="font-mono font-semibold tabular ${i === 0 ? 'c-ok' : 'c-2'}">${d.ms.toFixed(1)} ms</span>
            </div>
            <div class="h-2 rounded-full overflow-hidden" style="background: var(--track);">
              <div class="h-full rounded-full transition-all duration-500" style="width:${w}%; background:${i === 0 ? 'var(--ok)' : 'var(--ink-3)'}; opacity:${i === 0 ? '1' : '0.4'};"></div>
            </div>
          </div>
        `;
      }).join('');
    }

    async function runDnsRace() {
      chime(600, 0.04);
      showToast('Racing live Anycast DNS resolvers over active uplink...');
      try {
        const res = await fetch('/api/bench');
        if (res.ok) {
          const list = await res.json();
          if (list && list.length > 0) {
            DNS_SERVERS.length = 0;
            list.forEach(item => {
              DNS_SERVERS.push({
                ip: item.Ip,
                name: item.Name,
                note: item.DnsMs >= 0 ? `DNS: ${item.DnsMs}ms` : 'Ping Target',
                ms: item.PingAvg >= 0 ? item.PingAvg : (item.DnsMs >= 0 ? item.DnsMs : 99)
              });
            });
            DNS_SERVERS.sort((a, b) => a.ms - b.ms);
            renderDnsRace();
            chime(820, 0.06);
            showToast(`Fastest server: ${DNS_SERVERS[0].name} (${DNS_SERVERS[0].ms.toFixed(1)} ms)`);
            return;
          }
        }
      } catch (e) {}

      // Fallback
      setTimeout(() => {
        DNS_SERVERS.forEach(d => {
          d.ms = d.ip === '1.1.1.1' ? +(3.0 + Math.random() * 1.9) :
                 d.ip === '172.16.1.2' ? +(5.1 + Math.random() * 2.5) :
                 d.ip === '9.9.9.9' ? +(9.2 + Math.random() * 3.1) :
                 +(12.1 + Math.random() * 4.2);
        });
        DNS_SERVERS.sort((a, b) => a.ms - b.ms);
        renderDnsRace();
        chime(820, 0.06);
        showToast(`Fastest server: ${DNS_SERVERS[0].name} (${DNS_SERVERS[0].ms.toFixed(1)} ms)`);
      }, 420);
    }

    function selectDnsProfile(name) {
      activeDnsProfile = name;
      document.querySelectorAll('.dns-seg').forEach(b => b.setAttribute('data-active', b.dataset.dns === name ? 'true' : 'false'));
      addLedger('dns', `DNS Profile → ${name}`, 'Applied resolver settings & flushed local cache');
      chime(640, 0.04);
      showToast(`DNS set to ${name}`);
    }

    function selectRouteProfile(name) {
      activeRouteProfile = name;
      document.querySelectorAll('.rt-row').forEach(row => {
        const on = row.dataset.rt === name;
        row.style.borderColor = on ? 'var(--ok)' : 'var(--hairline)';
        const chk = row.querySelector('.rt-check');
        chk.style.background = on ? 'var(--ok)' : 'var(--track)';
        chk.style.color = '#FFFFFF';
        chk.textContent = on ? '✓' : '';
      });
      const wifiFirst = name === 'Wifi';
      document.getElementById('routeSummaryBox').innerHTML = `
        <div class="flex justify-between"><span class="c-3">0.0.0.0/0 Primary</span><span class="c-1 font-semibold">${wifiFirst ? 'Wi-Fi (Metric 15)' : 'Ethernet (Metric 10)'}</span></div>
        <div class="flex justify-between"><span class="c-3">0.0.0.0/0 Backup</span><span class="c-2">${wifiFirst ? 'Ethernet (Metric 50)' : 'Wi-Fi (Metric 40)'}</span></div>
        <div class="flex justify-between"><span class="c-3">10.114.0.5/32 Portal</span><span class="c-ok font-semibold">Pinned to Ethernet</span></div>
      `;
      addLedger('route', `Traffic Priority → ${name}`, 'Updated multi-homed interface metric preference');
      chime(640, 0.04);
      showToast(`Traffic balance set to ${name}`);
    }

    function syncPassCard() {
      const v = document.getElementById('vaultUser').value.trim();
      document.getElementById('passCardUser').textContent = v || 'Not configured';
    }

    function togglePasswordEye() {
      const inp = document.getElementById('vaultPass');
      const show = inp.type === 'password';
      inp.type = show ? 'text' : 'password';
      document.getElementById('eyeLabel').textContent = show ? 'Hide' : 'Show';
    }

    async function saveVault() {
      const u = document.getElementById('vaultUser').value.trim();
      const p = document.getElementById('vaultPass').value;
      if (!u || !p) { showToast('Please enter both username and password'); return; }
      try {
        const res = await fetch('/api/cred', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ u, p, h: 'gateway.nitjsr.ac.in', port: 8888 })
        });
        const r = await res.json();
        document.getElementById('vaultPill').textContent = 'Saved & Ready';
        document.getElementById('navBadgeVault').style.background = 'var(--ok)';
        addLedger('system', 'Updated Encrypted Vault', `Stored DPAPI portal credentials for ${u}`);
        chime(780, 0.06);
        showToast(r.result || `Encrypted login saved for ${u}`);
      } catch (err) {
        showToast('Error saving vault: ' + err.message);
      }
    }

    async function clearVault() {
      document.getElementById('vaultPass').value = '';
      try {
        await fetch('/api/action', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ cmd: 'cred' })
        });
      } catch {}
      document.getElementById('vaultPill').textContent = 'Empty';
      document.getElementById('navBadgeVault').style.background = 'var(--track)';
      showToast('Saved portal credentials cleared');
    }

    async function testSignIn() {
      showToast('Executing captive portal authentication...');
      try {
        const res = await fetch('/api/action', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ cmd: 'login' })
        });
        const r = await res.json();
        addLedger('system', 'Portal Sign-In', r.result);
        chime(860, 0.07);
        showToast(r.result);
        if (typeof pollLiveStatus === 'function') pollLiveStatus();
      } catch (err) {
        showToast('Sign-in error: ' + err.message);
      }
    }

    async function loadVault() {
      try {
        const res = await fetch('/api/cred');
        if (res.ok) {
          const c = await res.json();
          if (c.Exists && c.User) {
            document.getElementById('vaultUser').value = c.User;
            syncPassCard();
            document.getElementById('vaultPill').textContent = 'Saved & Ready';
            document.getElementById('navBadgeVault').style.background = 'var(--ok)';
          }
        }
      } catch {}
    }

    function reverifyGatewayCert() {
      document.getElementById('certMatchTag').textContent = 'Verified Now';
      chime(720, 0.05);
      showToast('TLS 1.3 SHA-256 fingerprint matched');
    }

    function renderTuneSwitches() {
      document.getElementById('tuneSwitches').innerHTML = TUNE_SWITCHES.map((t, i) => `
        <div class="py-3.5 first:pt-0 last:pb-0 flex items-center justify-between gap-4">
          <div class="space-y-0.5">
            <div class="text-xs font-semibold c-1">${t.title}</div>
            <div class="text-[11px] c-3 leading-relaxed">${t.desc}</div>
          </div>
          <button onclick="TUNE_SWITCHES[${i}].on=!TUNE_SWITCHES[${i}].on; renderTuneSwitches(); chime(580, 0.03);" class="mac-switch" data-on="${t.on}" aria-label="${t.title}"></button>
        </div>
      `).join('');
    }

    function applyTuning() {
      const count = TUNE_SWITCHES.filter(x => x.on).length;
      addLedger('system', 'Applied Low-Latency Tuning', `Optimized ${count} Windows stack settings with backup`);
      chime(800, 0.06);
      showToast(`Applied ${count} low-latency optimizations`);
    }

    function renderRecoveryLadder() {
      document.getElementById('recoveryLadder').innerHTML = RECOVERY_TIERS.map(r => `
        <button onclick="openRecoveryTier(${r.tier})" class="w-full btn-glass rounded-2xl p-3.5 text-left flex items-center justify-between gap-3">
          <div class="space-y-0.5 min-w-0">
            <div class="flex items-center gap-2 flex-wrap">
              <span class="text-xs font-semibold c-1">${r.title}</span>
              <span class="text-[10px] font-semibold px-2 py-0.5 rounded-full" style="background:${toneSoftVar(r.tone)}; color:${toneVar(r.tone)};">${r.badge}</span>
            </div>
            <div class="text-[11px] c-3 truncate">${r.desc}</div>
          </div>
          <svg class="w-4 h-4 c-3 shrink-0" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M9 18l6-6-6-6"/></svg>
        </button>
      `).join('');
    }

    function openRecoveryTier(tier) {
      const item = RECOVERY_TIERS.find(x => x.tier === tier);
      if (!item.confirm) { applyTuning(); return; }
      pendingRecovery = item;
      const b = document.getElementById('confBadge');
      b.textContent = `Tier ${item.tier} · ${item.badge}`;
      b.style.color = toneVar(item.tone);
      b.style.background = toneSoftVar(item.tone);
      document.getElementById('confTitle').textContent = item.title;
      document.getElementById('confDesc').textContent = item.desc + ' A pre-change backup is snapshotted automatically first.';
      document.getElementById('confTypedBox').classList.toggle('hidden', !item.typed);
      document.getElementById('confInput').value = '';
      document.getElementById('confirmBackdrop').classList.remove('hidden');
    }

    function closeConfirm() {
      document.getElementById('confirmBackdrop').classList.add('hidden');
      pendingRecovery = null;
    }

    async function confirmRecoveryAction() {
      if (!pendingRecovery) return;
      if (pendingRecovery.typed && document.getElementById('confInput').value.trim().toLowerCase() !== 'yes') {
        showToast('Please type "yes" to proceed');
        return;
      }
      const r = pendingRecovery;
      closeConfirm();

      const tierCmds = { 1: 'tune1', 2: 'restore', 3: 'repair', 4: 'reset', 5: 'pnp', 6: 'reset' };
      const cmd = tierCmds[r.tier] || 'repair';
      showToast(`Executing Tier ${r.tier}: ${r.title}...`);

      try {
        const res = await fetch('/api/action', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ cmd })
        });
        const resJson = await res.json();
        addLedger('system', r.title, resJson.result);
        showToast(resJson.result);
        chime(840, 0.07);
        if (typeof pollLiveStatus === 'function') pollLiveStatus();
      } catch (err) {
        showToast('Action error: ' + err.message);
      }
    }

    async function quickFlush() {
      showToast('Flushing network caches & asserting route shield...');
      try {
        const res = await fetch('/api/action', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ cmd: 'repair' })
        });
        const r = await res.json();
        addLedger('dns', 'Flushed Network Caches', r.result);
        chime(720, 0.04);
        showToast(r.result);
        if (typeof pollLiveStatus === 'function') pollLiveStatus();
      } catch (err) {
        showToast('Flush error: ' + err.message);
      }
    }

    function filterActivity(cat) {
      activityFilter = cat;
      document.querySelectorAll('.act-seg').forEach(b => b.setAttribute('data-active', b.dataset.actF === cat ? 'true' : 'false'));
      renderLedger();
    }

    function addLedger(cat, title, detail) {
      LEDGER.unshift({ id: Math.random().toString(16).slice(2, 6), cat, time: 'Just now', title, detail });
      renderLedger();
    }

    function renderLedger() {
      document.getElementById('navBadgeLedger').textContent = LEDGER.length;
      const list = activityFilter === 'all' ? LEDGER : LEDGER.filter(x => x.cat === activityFilter);
      document.getElementById('ledgerMeta').textContent = `${list.length} reversible ${list.length === 1 ? 'entry' : 'entries'}`;

      const el = document.getElementById('ledgerRows');
      if (list.length === 0) {
        el.innerHTML = '<div class="py-10 text-center text-xs c-3">No matching entries — system is at baseline.</div>';
        return;
      }
      el.innerHTML = list.map(item => `
        <div class="mac-inset rounded-2xl p-3.5 flex items-center justify-between gap-3">
          <div class="min-w-0 space-y-0.5">
            <div class="flex items-center gap-2">
              <span class="text-xs font-semibold c-1 truncate">${item.title}</span>
              <span class="text-[11px] c-3 shrink-0">${item.time}</span>
            </div>
            <div class="text-[11px] c-2 truncate">${item.detail}</div>
          </div>
          <button onclick="undoById('${item.id}')" class="btn-glass rounded-full px-3 py-1.5 text-[11px] font-semibold shrink-0">Undo</button>
        </div>
      `).join('');
    }

    function undoById(id) {
      const idx = LEDGER.findIndex(x => x.id === id);
      if (idx < 0) return;
      const [rem] = LEDGER.splice(idx, 1);
      renderLedger();
      chime(520, 0.05);
      showToast(`Undid: ${rem.title}`);
    }

    async function undoLast() {
      showToast('Executing write-ahead rollback...');
      try {
        const res = await fetch('/api/action', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ cmd: 'rollback' })
        });
        const r = await res.json();
        showToast(r.result);
        chime(520, 0.05);
        if (LEDGER.length > 0) undoById(LEDGER[0].id);
        if (typeof pollLiveStatus === 'function') pollLiveStatus();
      } catch (err) {
        showToast('Rollback error: ' + err.message);
      }
    }

    function togglePrivacy() {
      strictPrivacy = !strictPrivacy;
      document.getElementById('redactSwitch').setAttribute('data-on', strictPrivacy ? 'true' : 'false');
      renderPrivacyCard();
      chime(600, 0.035);
    }

    function renderPrivacyCard() {
      document.getElementById('privacyCard').innerHTML = strictPrivacy
        ? `
          <div class="flex justify-between"><span class="c-3">Host &amp; User</span><span class="c-ok font-semibold">[REDACTED]</span></div>
          <div class="flex justify-between"><span class="c-3">Hardware MAC</span><span class="c-ok font-semibold">XX:XX:XX:XX:XX:XX</span></div>
          <div class="flex justify-between"><span class="c-3">Public IPv4 / v6</span><span class="c-ok font-semibold">[PUBLIC_IP_REDACTED]</span></div>
          <div class="flex justify-between"><span class="c-3">Campus Subnet</span><span class="c-1">10.114.230.187 (Kept)</span></div>
        `
        : `
          <div class="flex justify-between"><span class="c-3">Host &amp; User</span><span class="c-1">DESKTOP-07 · abhishek</span></div>
          <div class="flex justify-between"><span class="c-3">Hardware MAC</span><span class="c-1">A8-5E-45-9C-21-0B</span></div>
          <div class="flex justify-between"><span class="c-3">Public IPv4 / v6</span><span class="c-1">103.21.124.88 · 2401:4900::44</span></div>
          <div class="flex justify-between"><span class="c-3">Campus Subnet</span><span class="c-1">10.114.230.187</span></div>
        `;
    }

    function exportBundle() {
      chime(820, 0.06);
      showToast(strictPrivacy ? 'Exporting privacy-safe diagnostic bundle...' : 'Exporting diagnostic bundle...');
      window.location.href = '/api/bundle';
    }

    // =========================================================================
    // INSPECTOR SHEET & SPOTLIGHT ⌘K COMMAND PALETTE
    // =========================================================================
    async function openInspector() {
      document.getElementById('inspectorSheet').classList.remove('hidden');
      chime(620, 0.035);
      try {
        const res = await fetch('/api/doctor');
        if (!res.ok) return;
        const d = await res.json();
        if (d && d.Layers && d.Layers.length > 0) {
          document.getElementById('inspectorList').innerHTML = d.Layers.map(l => {
            const ok = l.Status === 'OK';
            const tone = ok ? 'ok' : 'bad';
            return `
              <div class="mac-inset rounded-2xl p-4 space-y-1">
                <div class="flex items-center justify-between">
                  <span class="text-xs font-semibold c-1">Layer ${l.Layer} · ${l.Name}</span>
                  <span class="text-[10px] font-semibold px-2 py-0.5 rounded-full" style="background:${toneSoftVar(tone)}; color:${toneVar(tone)};">
                    ${ok ? 'Healthy' : 'Attention'}
                  </span>
                </div>
                <p class="text-xs c-2 leading-relaxed font-mono text-[11px]">${l.Evidence}</p>
              </div>
            `;
          }).join('');
        }
      } catch (e) {}
    }
    function closeInspector() { document.getElementById('inspectorSheet').classList.add('hidden'); }

    const COMMANDS = [
      { title: 'Optimize & Stabilize Connection', sub: 'Run 7-layer repair and verify TLS', run: () => { switchTab('home'); runHeroChoreography(); } },
      { title: 'Run DNS Speed Race', sub: 'Find the fastest resolver over Ethernet', run: () => { switchTab('speed'); runDnsRace(); } },
      { title: 'Flush Network Caches', sub: 'Clear DNS, ARP, and NetBIOS tables', run: () => quickFlush() },
      { title: 'Open 7-Layer Health Inspector', sub: 'Inspect every network layer in detail', run: () => openInspector() },
      { title: 'Sign Into Campus Portal', sub: 'Authenticate silently via DPAPI vault', run: () => testSignIn() },
      { title: 'Undo Latest Change', sub: 'Revert most recent ledger entry safely', run: () => undoLast() },
      { title: 'Toggle Light / Dark Silk Mode', sub: 'Switch studio appearance', run: () => toggleMode() },
      { title: 'Simulate: Portal Sign-In Needed', sub: 'Preview captive portal state', run: () => { switchTab('home'); setScenario('captive'); } },
      { title: 'Simulate: DNS Issue', sub: 'Preview DNS failure detection', run: () => { switchTab('home'); setScenario('nodns'); } },
      { title: 'Simulate: Wi-Fi Backup Active', sub: 'Preview dual-uplink protection', run: () => { switchTab('home'); setScenario('dual'); } },
      { title: 'Simulate: Connected & Healthy', sub: 'Preview normal gigabit link', run: () => { switchTab('home'); setScenario('healthy'); } }
    ];

    function openSpotlight() {
      document.getElementById('spotlightBackdrop').classList.remove('hidden');
      const inp = document.getElementById('spotlightInput');
      inp.value = '';
      renderSpotlight();
      setTimeout(() => inp.focus(), 20);
    }

    function closeSpotlight() {
      document.getElementById('spotlightBackdrop').classList.add('hidden');
    }

    function renderSpotlight() {
      const q = document.getElementById('spotlightInput').value.trim().toLowerCase();
      const hits = COMMANDS.filter(c => !q || c.title.toLowerCase().includes(q) || c.sub.toLowerCase().includes(q));
      document.getElementById('spotlightResults').innerHTML = hits.length
        ? hits.map((c, idx) => `
          <button onclick="runCommand(${COMMANDS.indexOf(c)})" class="nav-row w-full text-left px-3.5 py-2.5 rounded-xl flex items-center justify-between gap-3">
            <div>
              <div class="text-xs font-semibold c-1">${c.title}</div>
              <div class="text-[11px] c-3">${c.sub}</div>
            </div>
            <span class="text-[10px] font-mono c-3">↵</span>
          </button>
        `).join('')
        : '<div class="py-8 text-center text-xs c-3">No matching commands</div>';
    }

    function runCommand(idx) {
      closeSpotlight();
      COMMANDS[idx].run();
    }

    document.addEventListener('keydown', e => {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'k') {
        e.preventDefault();
        const hidden = document.getElementById('spotlightBackdrop').classList.contains('hidden');
        hidden ? openSpotlight() : closeSpotlight();
      } else if (e.key === 'Escape') {
        closeSpotlight();
        closeInspector();
        closeConfirm();
      }
    });

    function copyText(text, msg) {
      const ta = document.createElement('textarea');
      ta.value = text; document.body.appendChild(ta); ta.select();
      document.execCommand('copy'); document.body.removeChild(ta);
      chime(700, 0.035);
      showToast(msg);
    }

    let toastTimer = null;
    function showToast(msg) {
      const el = document.getElementById('toast');
      document.getElementById('toastMsg').textContent = msg;
      document.getElementById('toastDot').style.background = toneVar(SCENARIOS[currentScenario].tone);
      el.classList.remove('-translate-y-24', 'opacity-0');
      clearTimeout(toastTimer);
      toastTimer = setTimeout(() => el.classList.add('-translate-y-24', 'opacity-0'), 2400);
    }

    // =========================================================================
    // LIVING SPATIAL SIGNAL ORB (HIGH-DPI FLUID RING & GLASS SPHERE)
    // =========================================================================
    const orbCanvas = document.getElementById('orbCanvas');
    const octx = orbCanvas.getContext('2d');
    let orbT = 0;

    function resizeOrb() {
      const r = orbCanvas.parentElement.getBoundingClientRect();
      if (!r.width) return;
      const dpr = window.devicePixelRatio || 1;
      orbCanvas.width = r.width * dpr;
      orbCanvas.height = r.height * dpr;
      octx.setTransform(dpr, 0, 0, dpr, 0, 0);
    }

    function drawOrb() {
      orbT += isChoreoRunning ? 0.08 : 0.025;
      const dpr = window.devicePixelRatio || 1;
      const w = orbCanvas.width / dpr;
      const h = orbCanvas.height / dpr;
      if (w > 0 && h > 0) {
        octx.clearRect(0, 0, w, h);
        const cx = w / 2, cy = h / 2;
        const col = toneHex(SCENARIOS[currentScenario].tone);

        // Two gentle expanding organic light ripples
        for (let i = 0; i < 2; i++) {
          const phase = ((orbT * 0.35 + i * 0.5) % 1);
          const rad = 24 + phase * (Math.min(w, h) * 0.46 - 24);
          const alpha = (1 - phase) * (appMode === 'dark' ? 0.32 : 0.24);
          octx.beginPath();
          octx.arc(cx, cy, rad, 0, Math.PI * 2);
          octx.strokeStyle = col;
          octx.globalAlpha = alpha;
          octx.lineWidth = 1.6;
          octx.stroke();
        }
        octx.globalAlpha = 1;

        // Soft glowing core sphere
        const pulse = Math.sin(orbT) * 2.2;
        const coreR = 28 + pulse * 0.4;
        const grad = octx.createRadialGradient(cx - 8, cy - 8, 2, cx, cy, coreR + 8);
        grad.addColorStop(0, appMode === 'dark' ? 'rgba(255,255,255,0.22)' : 'rgba(255,255,255,0.95)');
        grad.addColorStop(0.55, col + (appMode === 'dark' ? '33' : '24'));
        grad.addColorStop(1, col + '08');

        octx.beginPath();
        octx.arc(cx, cy, coreR, 0, Math.PI * 2);
        octx.fillStyle = grad;
        octx.fill();

        octx.lineWidth = 1.25;
        octx.strokeStyle = col + (appMode === 'dark' ? '66' : '44');
        octx.stroke();
      }
      requestAnimationFrame(drawOrb);
    }

    // =========================================================================
    // APPLE-STOCKS-GRADE BEZIER SPLINE LATENCY GRAPH
    // =========================================================================
    const spCanvas = document.getElementById('splineCanvas');
    const spCtx = spCanvas.getContext('2d');

    function resizeSpline() {
      const r = spCanvas.parentElement.getBoundingClientRect();
      if (!r.width) return;
      const dpr = window.devicePixelRatio || 1;
      spCanvas.width = r.width * dpr;
      spCanvas.height = r.height * dpr;
      spCtx.setTransform(dpr, 0, 0, dpr, 0, 0);
      drawSpline();
    }

    function drawSpline() {
      const dpr = window.devicePixelRatio || 1;
      const w = spCanvas.width / dpr;
      const h = spCanvas.height / dpr;
      if (w <= 0 || h <= 0) return;
      spCtx.clearRect(0, 0, w, h);

      // Subtle reference hairlines
      spCtx.strokeStyle = appMode === 'dark' ? 'rgba(255,255,255,0.05)' : 'rgba(15,23,42,0.05)';
      spCtx.lineWidth = 1;
      [0.33, 0.66].forEach(frac => {
        spCtx.beginPath();
        spCtx.moveTo(0, h * frac);
        spCtx.lineTo(w, h * frac);
        spCtx.stroke();
      });

      const s = SCENARIOS[currentScenario];
      if (s.rttBase < 0) return;

      const col = toneHex(s.tone);
      const maxVal = Math.max(8, ...rttSeries) * 1.35;
      const step = w / (rttSeries.length - 1);
      const pts = rttSeries.map((v, i) => ({
        x: i * step,
        y: h - 18 - (v / maxVal) * (h - 38)
      }));

      // Translucent silk fill
      const g = spCtx.createLinearGradient(0, 0, 0, h);
      g.addColorStop(0, col + '33');
      g.addColorStop(1, col + '00');

      spCtx.beginPath();
      spCtx.moveTo(pts[0].x, pts[0].y);
      for (let i = 0; i < pts.length - 1; i++) {
        const xc = (pts[i].x + pts[i + 1].x) / 2;
        const yc = (pts[i].y + pts[i + 1].y) / 2;
        spCtx.quadraticCurveTo(pts[i].x, pts[i].y, xc, yc);
      }
      spCtx.lineTo(pts[pts.length - 1].x, pts[pts.length - 1].y);
      spCtx.lineTo(w, h);
      spCtx.lineTo(0, h);
      spCtx.closePath();
      spCtx.fillStyle = g;
      spCtx.fill();

      // Smooth stroke
      spCtx.beginPath();
      spCtx.moveTo(pts[0].x, pts[0].y);
      for (let i = 0; i < pts.length - 1; i++) {
        const xc = (pts[i].x + pts[i + 1].x) / 2;
        const yc = (pts[i].y + pts[i + 1].y) / 2;
        spCtx.quadraticCurveTo(pts[i].x, pts[i].y, xc, yc);
      }
      spCtx.lineTo(pts[pts.length - 1].x, pts[pts.length - 1].y);
      spCtx.strokeStyle = col;
      spCtx.lineWidth = 2.4;
      spCtx.lineCap = 'round';
      spCtx.stroke();

      // Pointer scrub point
      if (hoverIdx >= 0 && hoverIdx < pts.length) {
        const p = pts[hoverIdx];
        spCtx.beginPath();
        spCtx.moveTo(p.x, 10);
        spCtx.lineTo(p.x, h - 10);
        spCtx.strokeStyle = col + '44';
        spCtx.lineWidth = 1;
        spCtx.stroke();

        spCtx.beginPath();
        spCtx.arc(p.x, p.y, 4.5, 0, Math.PI * 2);
        spCtx.fillStyle = col;
        spCtx.fill();
        spCtx.strokeStyle = appMode === 'dark' ? '#1B1E25' : '#FFFFFF';
        spCtx.lineWidth = 2;
        spCtx.stroke();
      }
    }

    function handleScrub(clientX) {
      const r = spCanvas.getBoundingClientRect();
      const ratio = (clientX - r.left) / r.width;
      hoverIdx = Math.max(0, Math.min(rttSeries.length - 1, Math.round(ratio * (rttSeries.length - 1))));
      const tip = document.getElementById('splineTip');
      if (SCENARIOS[currentScenario].rttBase >= 0) {
        tip.textContent = `${rttSeries[hoverIdx].toFixed(1)} ms`;
        tip.classList.remove('hidden');
      }
      drawSpline();
    }
    spCanvas.addEventListener('mousemove', e => handleScrub(e.clientX));
    spCanvas.addEventListener('touchmove', e => { if (e.touches[0]) handleScrub(e.touches[0].clientX); }, { passive: true });
    spCanvas.addEventListener('mouseleave', () => { hoverIdx = -1; document.getElementById('splineTip').classList.add('hidden'); drawSpline(); });
    spCanvas.addEventListener('touchend', () => { hoverIdx = -1; document.getElementById('splineTip').classList.add('hidden'); drawSpline(); });

    setInterval(() => {
      const base = SCENARIOS[currentScenario].rttBase;
      if (base < 0) return;
      const v = Math.max(0.9, +(base + (Math.random() - 0.48) * 1.2).toFixed(1));
      rttSeries.push(v);
      if (rttSeries.length > 44) rttSeries.shift();

      const recent = rttSeries.slice(-14);
      let jit = 0;
      for (let i = 1; i < recent.length; i++) jit += Math.abs(recent[i] - recent[i - 1]);
      jit /= (recent.length - 1);

      document.getElementById('metricRtt').textContent = v.toFixed(1);
      document.getElementById('metricJitter').textContent = `${jit.toFixed(1)} ms`;
      document.getElementById('navBadgeHome').textContent = `${Math.round(v)} ms`;
      if (currentTab === 'home') drawSpline();
    }, 550);

    // =========================================================================
    // LIVING ORGANIC AURORA BACKDROP CANVAS
    // =========================================================================
    const amb = document.getElementById('auroraCanvas');
    const actx = amb.getContext('2d');
    let ambT = 0;

    function resizeAmb() {
      amb.width = window.innerWidth;
      amb.height = window.innerHeight;
    }

    function animateAmb() {
      ambT += 0.0035;
      const w = amb.width, h = amb.height;
      actx.clearRect(0, 0, w, h);

      const tone = SCENARIOS[currentScenario].tone;
      const alpha = appMode === 'dark' ? 0.16 : 0.22;
      const pal = {
        ok:   ['rgba(16, 185, 129, ', 'rgba(56, 189, 248, '],
        warn: ['rgba(245, 158, 11, ', 'rgba(251, 146, 60, '],
        blue: ['rgba(59, 130, 246, ', 'rgba(99, 102, 241, '],
        bad:  ['rgba(239, 68, 68, ',  'rgba(244, 114, 182, ']
      }[tone];

      const x1 = w * (0.22 + Math.sin(ambT) * 0.10);
      const y1 = h * (0.18 + Math.cos(ambT * 0.8) * 0.08);
      const g1 = actx.createRadialGradient(x1, y1, 0, x1, y1, Math.max(w, h) * 0.52);
      g1.addColorStop(0, pal[0] + alpha + ')');
      g1.addColorStop(1, pal[0] + '0)');
      actx.fillStyle = g1;
      actx.fillRect(0, 0, w, h);

      const x2 = w * (0.78 + Math.cos(ambT * 0.7) * 0.10);
      const y2 = h * (0.78 + Math.sin(ambT * 0.9) * 0.08);
      const g2 = actx.createRadialGradient(x2, y2, 0, x2, y2, Math.max(w, h) * 0.50);
      g2.addColorStop(0, pal[1] + alpha + ')');
      g2.addColorStop(1, pal[1] + '0)');
      actx.fillStyle = g2;
      actx.fillRect(0, 0, w, h);

      requestAnimationFrame(animateAmb);
    }

    // =========================================================================
    
    // =========================================================================
    // REAL-TIME WINDOWS NETWORK TELEMETRY PIPELINE
    // =========================================================================
    let isLiveMode = true;

    function onScenarioSelectChange(val) {
      if (val === 'live') {
        isLiveMode = true;
        showToast('⚡ Live Network Telemetry Active');
        pollLiveStatus();
      } else {
        isLiveMode = false;
        setScenario(val);
        showToast(`Simulated: ${SCENARIOS[val]?.short || val}`);
      }
    }

    async function pollLiveStatus() {
      if (!isLiveMode) return;
      try {
        const res = await fetch('/api/status');
        if (!res.ok) return;
        const s = await res.json();

        let st = (s.State || 'Offline').toLowerCase();
        let targetScenario = 'healthy';
        if (st === 'captive') targetScenario = 'captive';
        else if (st === 'nodns') targetScenario = 'nodns';
        else if (st === 'nolink' || st === 'offline' || st === 'starting') targetScenario = 'apipa';
        else if (st === 'online') {
          targetScenario = 'healthy';
        }

        if (currentScenario !== targetScenario) {
          setScenario(targetScenario);
        }

        if (s.Ms >= 0) {
          document.getElementById('metricRtt').textContent = s.Ms.toFixed(1);
          document.getElementById('navBadgeHome').textContent = Math.round(s.Ms) + ' ms';
          rttSeries.push(s.Ms);
          if (rttSeries.length > 44) rttSeries.shift();
          if (currentTab === 'home') drawSpline();
        } else if (targetScenario === 'apipa') {
          document.getElementById('metricRtt').textContent = '—';
          document.getElementById('navBadgeHome').textContent = 'Off';
        }

        if (s.GwMs >= 0) {
          document.getElementById('metaGw').textContent = s.Gw || 'None';
        }
        if (s.Ip) {
          document.getElementById('metaIp').textContent = s.Ip;
        }
        document.getElementById('metricLoss').textContent = (s.Loss || 0) + '%';
        if (s.Adapter) {
          document.getElementById('heroEnvTag').textContent = `${s.Adapter} · Verified Link`;
          updateRealUplinks(s);
        }

        if (s.Vault) {
          document.getElementById('vaultPill').textContent = 'Saved & Ready';
          document.getElementById('navBadgeVault').style.background = 'var(--ok)';
        }

        const evts = s.Events || s.Evts;
        if (evts && evts.length > 0) {
          updateRealLedger(evts);
        }
      } catch (err) {}
    }

    function updateRealUplinks(s) {
      const isEth = !(s.Adapter || '').toLowerCase().includes('wi-fi') && !(s.Adapter || '').toLowerCase().includes('wireless');
      const container = document.getElementById('uplinkCards');
      if (!container) return;
      container.innerHTML = `
        <div class="mac-inset rounded-2xl p-3.5 flex items-center justify-between gap-3">
          <div class="flex items-center gap-3 min-w-0">
            <div class="w-9 h-9 rounded-xl flex items-center justify-center shrink-0" style="background:var(--ok-soft);">
              <svg class="w-4 h-4 c-ok" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                ${isEth ? '<rect x="2" y="4" width="20" height="16" rx="3"/><path d="M8 10h8M10 14h4"/>' : '<path d="M5 12.55a11 11 0 0 1 14.08 0"/><path d="M8.53 16.11a6 6 0 0 1 6.95 0"/><circle cx="12" cy="19.5" r="1" fill="currentColor"/>'}
              </svg>
            </div>
            <div class="min-w-0">
              <div class="text-xs font-semibold c-1 truncate">${s.Adapter || 'Primary Interface'} · Active</div>
              <div class="font-mono text-[11px] c-3 truncate">${s.Ip || '10.x.x.x'} (Gateway: ${s.Gw || 'None'})</div>
            </div>
          </div>
          <span class="text-[10px] font-semibold px-2.5 py-1 rounded-full shrink-0" style="background:var(--ok-soft); color:var(--ok);">
            Primary · Active
          </span>
        </div>
      `;
    }

    function updateRealLedger(events) {
      if (!events || events.length === 0) return;
      events.slice(-6).forEach(e => {
        if (!LEDGER.some(x => x.detail === e)) {
          let cat = 'system';
          if (e.includes('DNS') || e.includes('dns')) cat = 'dns';
          else if (e.includes('route') || e.includes('shield')) cat = 'route';
          LEDGER.unshift({
            id: Math.random().toString(16).slice(2, 6),
            cat,
            time: 'Recent',
            title: e.length > 35 ? e.substring(0, 35) + '...' : e,
            detail: e
          });
        }
      });
      if (LEDGER.length > 20) LEDGER.length = 20;
      renderLedger();
    }

    // BOOTSTRAP
    // =========================================================================
    window.addEventListener('resize', () => { resizeAmb(); resizeSpline(); resizeOrb(); });
    window.onload = () => {
      resizeAmb();
      resizeOrb();
      resizeSpline();
      animateAmb();
      drawOrb();
      renderDnsRace();
      renderTuneSwitches();
      renderRecoveryLadder();
      renderLedger();
      renderPrivacyCard();
      selectRouteProfile('Adaptive');
      setScenario('healthy');
      if (typeof loadVault === 'function') loadVault();
      if (typeof pollLiveStatus === 'function') {
        pollLiveStatus();
        setInterval(pollLiveStatus, 1500);
      }
    };
  </script>
</body>
</html>
""";
}
